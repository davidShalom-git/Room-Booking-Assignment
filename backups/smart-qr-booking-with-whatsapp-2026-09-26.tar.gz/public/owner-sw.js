/**
 * Owner app service worker (scope /admin/): shows push notifications, and handles
 * Acknowledge / Not received right from the notification (POST /api/owner/act with the
 * notification's signed token). After Acknowledge, a follow-up notification opens the owner's
 * WhatsApp with the guest's confirmation already typed.
 */
const ICON = "/owner-icon/192";
const HOME = "/admin/today";

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

self.addEventListener("push", (event) => {
  let n = { title: "Update", body: "", url: HOME, actions: [] };
  try {
    if (event.data) n = { ...n, ...event.data.json() };
  } catch {
    if (event.data) n.body = event.data.text();
  }
  event.waitUntil(
    self.registration.showNotification(n.title || "Update", {
      body: n.body,
      icon: ICON,
      badge: "/owner-icon/96",
      tag: n.tag,
      renotify: Boolean(n.tag),
      requireInteraction: Boolean(n.token),
      actions: n.actions || [],
      data: { url: n.url || HOME, token: n.token },
    }),
  );
});

self.addEventListener("notificationclick", (event) => {
  const data = event.notification.data || {};
  event.notification.close();
  if ((event.action === "ack" || event.action === "nack") && data.token) {
    event.waitUntil(act(event.action, data.token));
  } else {
    event.waitUntil(open(data.url || HOME));
  }
});

async function act(action, token) {
  let r;
  try {
    const res = await fetch("/api/owner/act", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action, token }),
    });
    r = await res.json();
  } catch {
    r = { ok: false, error: "No internet connection — open the app to try again." };
  }
  if (r.ok && r.whatsapp) {
    return self.registration.showNotification("✅ Confirmed", {
      body: `${r.message}\nTap to send the guest their confirmation on WhatsApp.`,
      icon: ICON,
      data: { url: r.whatsapp },
    });
  }
  return self.registration.showNotification(r.ok ? "Done" : "⚠️ Couldn't do that", {
    body: r.ok ? r.message : r.error,
    icon: ICON,
    data: { url: HOME },
  });
}

async function open(url) {
  if (/^https:\/\/wa\.me\//.test(url)) return self.clients.openWindow(url);
  const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
  for (const w of windows) {
    if (new URL(w.url).pathname.startsWith("/admin")) {
      await w.focus();
      return w.navigate(url);
    }
  }
  return self.clients.openWindow(url);
}
