import { test, describe, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { prisma } from "../src/lib/db";
import { verifySignature, sign } from "../src/lib/wa/signature";
import { parseInbound } from "../src/lib/wa/inbound";
import { handleInbound } from "../src/lib/wa/handle";
import { deliver } from "../src/lib/wa/deliver";
import { GET, POST } from "../src/app/api/whatsapp/route";
import { resetDb, seedRooms } from "./helpers/db";
import { startMockGraph, metaPayload, textMsg, buttonMsg } from "./helpers/mockGraph";
import { GUEST, OWNER } from "./helpers/chat";

const SECRET = "app-secret-for-tests";
const QR = "Hi! I'm interested in *Room 101 — Deluxe Double Room*.\nhttps://x.app/rooms/101";
let mock: Awaited<ReturnType<typeof startMockGraph>>;
let n = 0;
const id = () => `wamid.test.${++n}`;

/** Feed Meta-shaped messages through the real parser and handler. */
const inbound = (...messages: Record<string, unknown>[]) => handleInbound(parseInbound(metaPayload(messages)));
const say = (from: string, text: string) => inbound(textMsg(id(), from, text));
const tap = (from: string, replyId: string) => inbound(buttonMsg(id(), from, replyId));

async function bookToReview() {
  await say(GUEST, QR);
  await tap(GUEST, "book");
  await say(GUEST, "Asha Nair");
  await tap(GUEST, "contact_wa");
  await say(GUEST, "2");
  await say(GUEST, "12 oct 2030");
  await say(GUEST, "2");
}

/** Book, hold, and send the UTR — which is what alerts the owner. */
async function bookAndClaim() {
  await bookToReview();
  await tap(GUEST, "confirm");
  const b = await prisma.booking.findFirstOrThrow();
  await tap(GUEST, `i_paid:${b.id}`);
  await say(GUEST, "412345678901");
  const p = await prisma.payment.findFirstOrThrow({ where: { bookingId: b.id } });
  return { b, p };
}

before(async () => {
  mock = await startMockGraph();
  Object.assign(process.env, {
    WA_API_BASE: mock.base,
    WA_ACCESS_TOKEN: "test-token",
    WA_PHONE_NUMBER_ID: "PNID",
    WA_APP_SECRET: SECRET,
    WA_VERIFY_TOKEN: "verify-me",
    OWNER_WHATSAPP: OWNER,
    UPI_ID: "coral@upi",
  });
});
after(() => mock.stop());
beforeEach(async () => {
  process.env["WA_TPL_NOTIFY"] = "";
  process.env["WA_TPL_LAST_DAY"] = "";
  mock.setStatus(200);
  mock.clear();
  await resetDb();
  await seedRooms([{ id: "101", price: 1800 }, { id: "102" }, { id: "103", capacity: 4 }, { id: "104" }]);
});

describe("signature", () => {
  const body = JSON.stringify({ hello: "wörld" });
  test("valid signature passes", () => {
    assert.equal(verifySignature(body, sign(body, SECRET), SECRET), true);
    assert.equal(verifySignature(Buffer.from(body), sign(body, SECRET), SECRET), true);
  });
  test("wrong secret, tampered body, missing or malformed header all fail", () => {
    assert.equal(verifySignature(body, sign(body, "other"), SECRET), false);
    assert.equal(verifySignature(body + " ", sign(body, SECRET), SECRET), false);
    assert.equal(verifySignature(body, null, SECRET), false);
    assert.equal(verifySignature(body, "sha256=abc", SECRET), false);
    assert.equal(verifySignature(body, "md5=" + "0".repeat(64), SECRET), false);
    assert.equal(verifySignature(body, sign(body, SECRET), ""), false);
  });
});

describe("route", () => {
  test("GET verification handshake", async () => {
    const good = await GET(new Request("http://x/api/whatsapp?hub.mode=subscribe&hub.verify_token=verify-me&hub.challenge=12345"));
    assert.equal(good.status, 200);
    assert.equal(await good.text(), "12345");
    const bad = await GET(new Request("http://x/api/whatsapp?hub.mode=subscribe&hub.verify_token=nope&hub.challenge=12345"));
    assert.equal(bad.status, 403);
  });

  test("POST rejects a bad signature before doing anything", async () => {
    const body = JSON.stringify(metaPayload([textMsg(id(), GUEST, QR)]));
    const res = await POST(new Request("http://x/api/whatsapp", { method: "POST", body, headers: { "x-hub-signature-256": sign(body, "wrong") } }));
    assert.equal(res.status, 401);
    assert.equal(mock.requests.length, 0);
    assert.equal(await prisma.conversation.count(), 0);
  });

  test("POST with a valid signature runs the bot and replies", async () => {
    const body = JSON.stringify(metaPayload([textMsg(id(), GUEST, QR)]));
    const res = await POST(new Request("http://x/api/whatsapp", { method: "POST", body, headers: { "x-hub-signature-256": sign(body, SECRET) } }));
    assert.equal(res.status, 200);
    assert.equal(mock.sentTo(GUEST).length, 1);
  });

  test("POST of a delivery-status update is acknowledged and ignored", async () => {
    const body = JSON.stringify({ object: "whatsapp_business_account", entry: [{ changes: [{ value: { statuses: [{ id: "x", status: "read" }] } }] }] });
    const res = await POST(new Request("http://x/api/whatsapp", { method: "POST", body, headers: { "x-hub-signature-256": sign(body, SECRET) } }));
    assert.equal(res.status, 200);
    assert.equal(mock.requests.length, 0);
  });
});

describe("parseInbound", () => {
  test("text, reply buttons, list replies, template buttons, media; statuses ignored", () => {
    const parsed = parseInbound(
      metaPayload([
        textMsg("a", "+91 98123 45678", "hello"),
        buttonMsg("b", GUEST, "book"),
        { id: "c", from: GUEST, type: "interactive", interactive: { type: "list_reply", list_reply: { id: "pick:102", title: "x" } } },
        { id: "d", from: GUEST, type: "button", button: { payload: "resend", text: "Show options" } },
        { id: "e", from: GUEST, type: "image", image: { id: "img" } },
        { id: "f", from: GUEST, type: "reaction", reaction: { emoji: "👍" } },
      ]),
    );
    assert.deepEqual(parsed, [
      { id: "a", event: { kind: "text", from: GUEST, text: "hello" } },
      { id: "b", event: { kind: "button", from: GUEST, id: "book" } },
      { id: "c", event: { kind: "button", from: GUEST, id: "pick:102" } },
      { id: "d", event: { kind: "button", from: GUEST, id: "resend" } },
      { id: "e", event: { kind: "media", from: GUEST } },
    ]);
    assert.deepEqual(parseInbound({}), []);
    assert.deepEqual(parseInbound(null), []);
    assert.deepEqual(parseInbound({ entry: [{ changes: [{ value: { statuses: [{}] } }] }] }), []);
  });
});

describe("handleInbound + Graph API", () => {
  test("a QR message gets the intro as an interactive reply-button message", async () => {
    await say(GUEST, QR);
    assert.equal(mock.requests.length, 1);
    const r = mock.requests[0]!;
    assert.equal(r.url, "/v99.0/PNID/messages");
    assert.equal(r.headers["authorization"], "Bearer test-token");
    assert.equal(r.body.messaging_product, "whatsapp");
    assert.equal(r.body.to, GUEST);
    assert.equal(r.body.type, "interactive");
    assert.equal(r.body.interactive.type, "button");
    assert.match(r.body.interactive.body.text, /Room 101/);
    assert.deepEqual(r.body.interactive.action.buttons[0], { type: "reply", reply: { id: "info", title: "About this room" } });
  });

  test("more than three options go out as a list message", async () => {
    await say(GUEST, "hi");
    const r = mock.sentTo(GUEST)[0]!;
    assert.equal(r.interactive.type, "list");
    assert.equal(r.interactive.action.sections[0].rows[0].id, "pick:101");
    assert.ok(r.interactive.action.button.length <= 20);
  });

  test("the same message id delivered twice is handled once", async () => {
    const m = textMsg("wamid.dup", GUEST, QR);
    await inbound(m);
    await inbound(m);
    assert.equal(mock.sentTo(GUEST).length, 1);
  });

  test("a Graph API failure doesn't lose the conversation state", async () => {
    mock.setStatus(500);
    assert.equal(await say(GUEST, QR), true);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { phone: GUEST } });
    assert.equal(conv.roomId, "101");
  });

  test("owner outside the 24h window, no template: the alert waits, then arrives when the owner writes in", async () => {
    const { b, p } = await bookAndClaim();
    assert.equal(b.status, "PENDING");
    assert.equal(mock.sentTo(OWNER).length, 0, "free-form would be rejected by WhatsApp, so nothing is sent");
    const queued = await prisma.conversation.findUniqueOrThrow({ where: { phone: OWNER } });
    assert.equal((queued.pendingOut as unknown[]).length, 1);

    await say(OWNER, "hi");
    const got = mock.sentTo(OWNER);
    assert.equal(got.length, 2);
    assert.deepEqual(got[0].interactive.action.buttons.map((x: { reply: { id: string } }) => x.reply.id), [`ack:${p.id}`, `nack:${p.id}`]);
    assert.match(got[1].text.body, /admin/i);
    const after = await prisma.conversation.findUniqueOrThrow({ where: { phone: OWNER } });
    assert.deepEqual(after.pendingOut, []);

    // now inside the window: the owner's tap confirms and the guest hears about it
    mock.clear();
    await tap(OWNER, `ack:${p.id}`);
    assert.equal((await prisma.booking.findUniqueOrThrow({ where: { id: b.id } })).status, "CONFIRMED");
    assert.match(mock.sentTo(GUEST)[0].text.body, /Booking confirmed/);
  });

  test("owner outside the window with a notify template: template ping, then 'Show options' delivers the alert", async () => {
    process.env["WA_TPL_NOTIFY"] = "coral_update";
    const { p } = await bookAndClaim();
    const ping = mock.sentTo(OWNER);
    assert.equal(ping.length, 1);
    assert.equal(ping[0].type, "template");
    assert.equal(ping[0].template.name, "coral_update");
    assert.equal(ping[0].template.language.code, "en");
    const text = ping[0].template.components[0].parameters[0].text as string;
    assert.match(text, /Asha Nair/);
    assert.doesNotMatch(text, /\n/, "template variables can't contain newlines");
    assert.deepEqual(ping[0].template.components[1], {
      type: "button", sub_type: "quick_reply", index: "0", parameters: [{ type: "payload", payload: "resend" }],
    });

    mock.clear();
    await inbound({ id: id(), from: OWNER, type: "button", button: { payload: "resend", text: "Show options" } });
    const got = mock.sentTo(OWNER);
    assert.equal(got.length, 1, "just the queued alert, no extra chatter");
    assert.equal(got[0].interactive.action.buttons[0].reply.id, `ack:${p.id}`);
  });

  test("'Show options' with nothing waiting says so", async () => {
    await inbound({ id: id(), from: OWNER, type: "button", button: { payload: "resend", text: "Show options" } });
    assert.match(mock.sentTo(OWNER)[0].text.body, /caught up/i);
  });

  test("last-day nudge outside the window uses the last-day template with per-booking button payloads", async () => {
    process.env["WA_TPL_LAST_DAY"] = "coral_last_day";
    await deliver([
      {
        to: GUEST,
        text: "Hi Asha 👋\nTomorrow is your last day",
        template: "last_day",
        params: ["Asha", "14 Oct 2030"],
        buttons: [{ id: "want_extend:b1", title: "Extend my stay" }, { id: "want_out:b1", title: "Check out" }],
      },
    ]);
    const m = mock.sentTo(GUEST)[0];
    assert.equal(m.template.name, "coral_last_day");
    assert.deepEqual(m.template.components[0].parameters, [{ type: "text", text: "Asha" }, { type: "text", text: "14 Oct 2030" }]);
    assert.equal(m.template.components[1].parameters[0].payload, "want_extend:b1");
    assert.equal(m.template.components[2].index, "1");
    assert.equal(m.template.components[2].parameters[0].payload, "want_out:b1");
  });

  test("two copies of the same tap processed at once: one hold, no 'just taken', chat stays consistent", async () => {
    await bookToReview();
    mock.clear();
    await Promise.all([tap(GUEST, "confirm"), tap(GUEST, "confirm")]);
    const holds = await prisma.booking.findMany({ where: { status: "PENDING" } });
    assert.equal(holds.length, 1);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { phone: GUEST } });
    assert.equal(conv.stage, "awaiting_payment");
    assert.equal((conv.draft as { bookingId?: string }).bookingId, holds[0]!.id);
    const texts = mock.sentTo(GUEST).map((m) => m.text?.body ?? m.interactive?.body?.text ?? "");
    assert.ok(texts.every((t: string) => !/just taken/i.test(t)), texts.join(" | "));
  });

  test("a queued alert whose delivery fails stays queued for next time", async () => {
    await bookAndClaim();
    mock.setStatus(500);
    await say(OWNER, "hi");
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { phone: OWNER } });
    assert.equal((conv.pendingOut as unknown[]).length, 1, "not lost");
    mock.setStatus(200);
    mock.clear();
    await say(OWNER, "hi");
    assert.ok(String(mock.sentTo(OWNER)[0].interactive.action.buttons[0].reply.id).startsWith("ack:"));
  });

  test("an owner alert that fails to send inside the window is kept for the owner's next message", async () => {
    await say(OWNER, "hi"); // owner is inside the 24h window
    mock.setStatus(500);
    const { p } = await bookAndClaim();
    mock.setStatus(200);
    mock.clear();
    await say(OWNER, "hi");
    assert.ok(mock.sentTo(OWNER).some((m) => m.interactive?.action?.buttons?.[0]?.reply?.id === `ack:${p.id}`));
  });

  test("messages to someone who wrote in recently go out free-form", async () => {
    await say(GUEST, QR);
    mock.clear();
    await deliver([{ to: GUEST, text: "hello again", template: "owner_alert" }]);
    assert.equal(mock.sentTo(GUEST)[0].type, "text");
  });
});
