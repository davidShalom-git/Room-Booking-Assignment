import { test, describe, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { prisma } from "../src/lib/db";
import { createBooking } from "../src/lib/engine";
import { addDays, todayISO } from "../src/lib/pricing";
import { GET as cron } from "../src/app/api/cron/last-day/route";
import { GET as availability } from "../src/app/api/availability/route";
import { resetDb, seedRooms } from "./helpers/db";
import { startMockGraph } from "./helpers/mockGraph";
import { GUEST } from "./helpers/chat";

let mock: Awaited<ReturnType<typeof startMockGraph>>;
const today = () => todayISO();
const req = (path: string, headers: Record<string, string> = {}) => new Request(`http://x${path}`, { headers });

before(async () => {
  mock = await startMockGraph();
  Object.assign(process.env, {
    WA_API_BASE: mock.base,
    WA_ACCESS_TOKEN: "test-token",
    WA_PHONE_NUMBER_ID: "PNID",
    CRON_SECRET: "cron-secret",
    WA_TPL_LAST_DAY: "coral_last_day",
  });
});
after(() => mock.stop());
beforeEach(async () => {
  mock.clear();
  await resetDb();
  await seedRooms([{ id: "101", price: 1800 }, { id: "102" }, { id: "103", capacity: 4 }]);
});

const stay = (roomId: string, checkIn: string, checkOut: string, status: "PENDING" | "CONFIRMED" = "CONFIRMED") =>
  createBooking({ roomId, guestName: "Asha Nair", guestPhone: GUEST, guests: 2, checkIn, checkOut, status, source: "ADMIN" });

describe("cron: last-day nudge", () => {
  test("refuses without the cron secret", async () => {
    assert.equal((await cron(req("/api/cron/last-day"))).status, 401);
    assert.equal((await cron(req("/api/cron/last-day", { authorization: "Bearer wrong" }))).status, 401);
  });

  test("nudges confirmed stays ending tomorrow, once per day, via the last-day template", async () => {
    const tomorrow = addDays(today(), 1);
    const b = await stay("101", today(), tomorrow);
    assert.ok(b.ok);
    await stay("102", today(), tomorrow, "PENDING");
    await stay("103", today(), addDays(today(), 2));

    const res = await cron(req("/api/cron/last-day", { authorization: "Bearer cron-secret" }));
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { sent: 1, for: tomorrow });
    const sent = mock.sentTo(GUEST);
    assert.equal(sent.length, 1);
    assert.equal(sent[0].template.name, "coral_last_day");
    assert.equal(sent[0].template.components[1].parameters[0].payload, `want_extend:${b.ok && b.value.id}`);

    const again = await cron(req("/api/cron/last-day", { authorization: "Bearer cron-secret" }));
    assert.equal((await again.json()).sent, 0);
    assert.equal(mock.sentTo(GUEST).length, 1);
  });

  test("never rewrites the guest's conversation (it may have moved on meanwhile)", async () => {
    const tomorrow = addDays(today(), 1);
    assert.ok((await stay("101", today(), tomorrow)).ok);
    const draft = { name: "Asha", intent: "book", checkIn: addDays(today(), 20) };
    await prisma.conversation.create({ data: { phone: GUEST, stage: "need_nights", draft, lastInboundAt: new Date() } });
    const res = await cron(req("/api/cron/last-day", { authorization: "Bearer cron-secret" }));
    assert.equal((await res.json()).sent, 1);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { phone: GUEST } });
    assert.equal(conv.stage, "need_nights");
    assert.deepEqual(conv.draft, draft);
  });

  test("clears old webhook dedupe markers", async () => {
    await prisma.processedMessage.create({ data: { id: "old", createdAt: new Date(Date.now() - 8 * 86_400_000) } });
    await prisma.processedMessage.create({ data: { id: "new" } });
    await cron(req("/api/cron/last-day", { authorization: "Bearer cron-secret" }));
    assert.deepEqual((await prisma.processedMessage.findMany()).map((m) => m.id), ["new"]);
  });
});

describe("availability API", () => {
  const url = (q: string) => req(`/api/availability?${q}`);
  const inDays = (d: number) => addDays(today(), d);

  test("free room: available with nights and total", async () => {
    const res = await availability(url(`room=101&from=${inDays(3)}&to=${inDays(5)}`));
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { available: true, nights: 2, total: 3600, ratePerNight: 1800 });
  });

  test("booked room: not available", async () => {
    await stay("101", inDays(4), inDays(6));
    const res = await availability(url(`room=101&from=${inDays(3)}&to=${inDays(5)}`));
    assert.equal((await res.json()).available, false);
  });

  test("too many guests for the room: not available", async () => {
    const res = await availability(url(`room=101&from=${inDays(3)}&to=${inDays(5)}&guests=3`));
    assert.equal((await res.json()).available, false);
  });

  test("bad input", async () => {
    for (const q of [
      `room=101&from=nope&to=${inDays(5)}`,
      `room=101&from=${inDays(5)}&to=${inDays(5)}`,
      `room=101&from=${inDays(5)}&to=${inDays(3)}`,
      `room=101&from=${inDays(1)}&to=${inDays(40)}`,
      `room=101&from=${inDays(-3)}&to=${inDays(1)}`,
    ]) {
      const res = await availability(url(q));
      assert.equal(res.status, 400, q);
      assert.ok((await res.json()).error);
    }
    assert.equal((await availability(url(`room=999&from=${inDays(3)}&to=${inDays(5)}`))).status, 404);
  });
});
