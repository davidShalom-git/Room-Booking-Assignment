import { test, describe, before, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { prisma } from "../src/lib/db";
import { ensureCustomer } from "../src/lib/engine";
import { createWebBooking, claimFromWeb, cancelWebHold, guestStays, pendingHoldFor, payState } from "../src/lib/web-booking";
import { resetDb, seedRooms } from "./helpers/db";

const OWNER = "919000000001";
const T0 = new Date("2026-10-01T10:00:00Z");
const input = (extra: Record<string, unknown> = {}) => ({
  roomId: "101", checkIn: "2026-10-12", checkOut: "2026-10-14", guests: 2, name: "Asha Nair", contactPhone: "", ...extra,
});

before(() => {
  process.env["OWNER_WHATSAPP"] = OWNER;
  process.env["WA_TPL_NOTIFY"] = "";
});
beforeEach(async () => {
  await resetDb();
  await seedRooms([{ id: "101", price: 1800 }, { id: "102", price: 1500 }]);
});

describe("the pay page", () => {
  test("offers UPI while the hold is live (or its payment is with the desk); a lapsed unpaid hold only takes a UTR", () => {
    const lapsed = { status: "CANCELLED" as const, holdExpiresAt: T0 };
    assert.equal(payState({ status: "PENDING", holdExpiresAt: T0 }, { status: "AWAITING" }), "pay");
    assert.equal(payState({ status: "PENDING", holdExpiresAt: T0 }, { status: "CLAIMED" }), "pay");
    assert.equal(payState(lapsed, { status: "CLAIMED" }), "pay");
    assert.equal(payState(lapsed, { status: "AWAITING" }), "expired");
    assert.equal(payState(lapsed, { status: "REJECTED" }), "expired");
    assert.equal(payState({ status: "CANCELLED", holdExpiresAt: null }, null), "none");
    assert.equal(payState({ status: "CONFIRMED", holdExpiresAt: null }, null), "none");
  });
});

describe("booking on the website", () => {
  test("creates a held WEB booking owing 50%, under the signed-in customer's number", async () => {
    const c = await ensureCustomer("919812345678");
    const r = await createWebBooking(c.id, input(), T0);
    assert.ok(r.ok, !r.ok ? r.message : "");
    const b = await prisma.booking.findUniqueOrThrow({ where: { id: r.value.id }, include: { payments: true } });
    assert.equal(b.source, "WEB");
    assert.equal(b.status, "PENDING");
    assert.equal(b.guestPhone, "919812345678");
    assert.equal(b.customerId, c.id);
    assert.deepEqual(b.payments.map((p) => [p.kind, p.amount, p.status]), [["ADVANCE", 1800, "AWAITING"]]);
    assert.equal((await prisma.customer.findUniqueOrThrow({ where: { id: c.id } })).name, "Asha Nair", "name learnt");
  });

  test("validation: name, dates, capacity, unknown customer, taken room", async () => {
    const c = await ensureCustomer("919812345678");
    assert.equal((await createWebBooking(c.id, input({ name: " " }), T0)).ok, false);
    assert.equal((await createWebBooking(c.id, input({ checkOut: "2026-10-12" }), T0)).ok, false);
    assert.equal((await createWebBooking(c.id, input({ guests: 3 }), T0)).ok, false);
    assert.equal((await createWebBooking(c.id, input({ contactPhone: "12" }), T0)).ok, false);
    assert.equal((await createWebBooking("nope", input(), T0)).ok, false);
    const other = await ensureCustomer("919000000077");
    assert.ok((await createWebBooking(other.id, input({ name: "Ravi" }), T0)).ok);
    const taken = await createWebBooking(c.id, input(), T0);
    assert.equal(!taken.ok && taken.code, "CONFLICT");
  });

  test("one unpaid hold per customer: the existing one is reported", async () => {
    const c = await ensureCustomer("919812345678");
    const first = await createWebBooking(c.id, input(), T0);
    assert.ok(first.ok);
    const second = await createWebBooking(c.id, input({ roomId: "102" }), T0);
    assert.equal(second.ok, false);
    assert.match(!second.ok ? second.message : "", /already have Room 101 on hold/);
    assert.equal((await pendingHoldFor("919812345678"))?.id, first.ok && first.value.id);
  });

  test("a UTR from the pay page claims the payment and alerts the owner (queued outside the 24h window)", async () => {
    const c = await ensureCustomer("919812345678");
    const r = await createWebBooking(c.id, input(), T0);
    assert.ok(r.ok);
    assert.equal((await claimFromWeb(r.value.id, "123")).ok, false);
    const claim = await claimFromWeb(r.value.id, "4123-4567-8901");
    assert.ok(claim.ok);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { phone: OWNER } });
    const queued = conv.pendingOut as { text: string; buttons: { id: string }[] }[];
    assert.equal(queued.length, 1);
    assert.match(queued[0]!.text, /Payment to check/);
    assert.match(queued[0]!.text, /UTR: \*412345678901\*/);
    assert.deepEqual(queued[0]!.buttons.map((b) => b.id), [`ack:${claim.ok && claim.value.id}`, `nack:${claim.ok && claim.value.id}`]);
  });

  test("a guest can cancel only their own hold", async () => {
    const c = await ensureCustomer("919812345678");
    const other = await ensureCustomer("919000000077");
    const r = await createWebBooking(c.id, input(), T0);
    assert.ok(r.ok);
    assert.equal((await cancelWebHold(other.id, r.value.id)).ok, false);
    assert.ok((await cancelWebHold(c.id, r.value.id)).ok);
    assert.equal((await prisma.booking.findUniqueOrThrow({ where: { id: r.value.id } })).status, "CANCELLED");
  });

  test("guestStays lists the customer's stays with their extensions, newest first", async () => {
    const c = await ensureCustomer("919812345678");
    const a = await createWebBooking(c.id, input(), T0);
    assert.ok(a.ok);
    await cancelWebHold(c.id, a.value.id);
    const b = await createWebBooking(c.id, input({ checkIn: "2026-11-01", checkOut: "2026-11-02" }), T0);
    assert.ok(b.ok);
    const stays = await guestStays(c.id);
    assert.deepEqual(stays.map((s) => s.root.id), [b.ok && b.value.id, a.value.id]);
    assert.equal(stays[0]!.payments.length, 1);
  });
});
