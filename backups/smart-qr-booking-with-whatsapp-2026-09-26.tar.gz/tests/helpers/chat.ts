import { step, lastDayNudges } from "../../src/lib/bot/step";
import type { ConvState, InEvent, Out, Ports } from "../../src/lib/bot/types";

export const GUEST = "919812345678";
export const OWNER = "919000000001";

export const blankConv = (phone: string): ConvState => ({ phone, roomId: null, stage: "browsing", draft: {} });

export const qrText = (room = "101", name = "Deluxe Double Room") =>
  `Hi! I'm interested in *Room ${room} — ${name}* at The Coral Courtyard.\nCould you tell me about availability?\nhttps://x.app/rooms/${room}`;

/** A tiny "WhatsApp world": one conversation per number, every outgoing message recorded. */
export function world(ports: Ports) {
  const convs = new Map<string, ConvState>();
  const log: Out[] = [];

  async function send(ev: InEvent): Promise<Out[]> {
    const conv = convs.get(ev.from) ?? blankConv(ev.from);
    const r = await step(conv, ev, ports);
    convs.set(ev.from, r.conv);
    log.push(...r.out);
    return r.out;
  }

  const w = {
    ports,
    log,
    conv: (phone: string) => convs.get(phone) ?? blankConv(phone),
    say: (from: string, text: string) => send({ kind: "text", from, text }),
    tap: (from: string, id: string) => send({ kind: "button", from, id }),
    media: (from: string) => send({ kind: "media", from }),
    /** Every message sent to `phone` so far. */
    to: (phone: string) => log.filter((o) => o.to === phone),
    lastTo: (phone: string) => log.filter((o) => o.to === phone).at(-1),
    /** Forget what was sent so far (assert only on what happens next). */
    clear: () => {
      log.length = 0;
    },
    /** Run the last-day cron for a check-out date; returns (and logs) the nudges sent. */
    nudge: async (tomorrow: string) => {
      const sent = await lastDayNudges(ports, tomorrow);
      log.push(...sent);
      return sent;
    },
    /** Overwrite a conversation — e.g. to simulate a save that never happened. */
    setConv: (phone: string, conv: ConvState) => void convs.set(phone, conv),
    /** Ids of buttons / list rows on a message. */
    ids: (o: Out | undefined) => [...(o?.buttons ?? []).map((b) => b.id), ...(o?.list?.rows ?? []).map((r) => r.id)],
  };
  return w;
}

/** Walk a guest through a booking up to (and including) the review screen. */
export async function bookUpToReview(
  w: ReturnType<typeof world>,
  opts: { from?: string; room?: string; name?: string; guests?: number; checkIn?: string; checkOut?: string } = {},
) {
  const from = opts.from ?? GUEST;
  await w.say(from, qrText(opts.room ?? "101"));
  await w.tap(from, "book");
  if (/Shall I book it under/.test(w.lastTo(from)?.text ?? "")) await w.tap(from, "name_yes");
  else await w.say(from, opts.name ?? "Asha Nair");
  await w.tap(from, "contact_wa");
  await w.say(from, String(opts.guests ?? 2));
  await w.say(from, opts.checkIn ?? "12 oct");
  await w.say(from, opts.checkOut ?? "14 oct");
}
