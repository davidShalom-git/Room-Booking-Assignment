import { createServer, type IncomingHttpHeaders } from "node:http";
import type { AddressInfo } from "node:net";

export type GraphCall = { url: string; headers: IncomingHttpHeaders; body: any }; // eslint-disable-line @typescript-eslint/no-explicit-any

/** A stand-in for graph.facebook.com: records every POST and answers like the Cloud API. */
export async function startMockGraph() {
  const requests: GraphCall[] = [];
  let status = 200;
  const server = createServer((req, res) => {
    let data = "";
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      requests.push({ url: req.url ?? "", headers: req.headers, body: data ? JSON.parse(data) : null });
      res.writeHead(status, { "content-type": "application/json" });
      res.end(JSON.stringify(status === 200 ? { messages: [{ id: "wamid.MOCK" }] } : { error: { message: "mock failure" } }));
    });
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = (server.address() as AddressInfo).port;
  return {
    base: `http://127.0.0.1:${port}/v99.0`,
    requests,
    /** Bodies of the messages sent to one number. */
    sentTo: (phone: string) => requests.filter((r) => r.body?.to === phone).map((r) => r.body),
    setStatus: (n: number) => { status = n; },
    clear: () => { requests.length = 0; },
    stop: () => new Promise<void>((resolve) => server.close(() => resolve())),
  };
}

/** Build the JSON Meta POSTs to the webhook. */
export function metaPayload(messages: Record<string, unknown>[]) {
  return {
    object: "whatsapp_business_account",
    entry: [{ id: "WABA", changes: [{ field: "messages", value: { messaging_product: "whatsapp", messages } }] }],
  };
}

export const textMsg = (id: string, from: string, body: string) => ({ id, from, type: "text", text: { body }, timestamp: "1" });
export const buttonMsg = (id: string, from: string, replyId: string) => ({
  id, from, type: "interactive", timestamp: "1",
  interactive: { type: "button_reply", button_reply: { id: replyId, title: "x" } },
});
