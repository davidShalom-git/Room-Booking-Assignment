import { test, describe, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { prisma } from "../src/lib/db";
import { requestCode, verifyCode, signInAvailable } from "../src/lib/guest-auth";
import { signGuestSession, verifyGuestSession, GUEST_MAX_AGE, signSession, verifySession } from "../src/lib/session";
import { resetDb, seedRooms } from "./helpers/db";

const T0 = new Date("2026-10-01T10:00:00Z");
const at = (seconds: number) => new Date(T0.getTime() + seconds * 1000);

/** A fake WhatsApp sender that remembers the last code per number. */
function outbox() {
  const codes = new Map<string, string>();
  const send = async (phone: string, code: string) => {
    codes.set(phone, code);
    return { ok: true as const };
  };
  return { codes, send };
}

beforeEach(async () => {
  process.env["SESSION_SECRET"] = "a-long-enough-session-secret-for-tests";
  await resetDb();
});

describe("requesting a code", () => {
  test("a valid number gets a 6-digit code; only its hash is stored", async () => {
    const o = outbox();
    const r = await requestCode("98123 45678", T0, o.send);
    assert.equal(r.ok, true);
    const code = o.codes.get("919812345678")!;
    assert.match(code, /^\d{6}$/);
    const row = await prisma.otpCode.findUniqueOrThrow({ where: { phone: "919812345678" } });
    assert.notEqual(row.codeHash, code);
    assert.ok(!row.codeHash.includes(code));
  });

  test("a bad number is refused", async () => {
    const r = await requestCode("12345", T0, outbox().send);
    assert.equal(r.ok, false);
  });

  test("one code a minute, five an hour", async () => {
    const o = outbox();
    assert.equal((await requestCode("+919812345678", T0, o.send)).ok, true);
    const tooSoon = await requestCode("+919812345678", at(30), o.send);
    assert.equal(tooSoon.ok, false);
    assert.match(!tooSoon.ok ? tooSoon.error : "", /wait 30 seconds/);
    for (let i = 1; i <= 4; i++) assert.equal((await requestCode("+919812345678", at(i * 61), o.send)).ok, true, `send ${i + 1}`);
    const sixth = await requestCode("+919812345678", at(5 * 61), o.send);
    assert.equal(sixth.ok, false);
    assert.match(!sixth.ok ? sixth.error : "", /Too many codes/);
    assert.equal((await requestCode("+919812345678", at(3700), o.send)).ok, true, "a new hour");
  });

  test("a burst of parallel requests sends one code and counts once", async () => {
    let sends = 0;
    const send = async () => {
      sends++;
      return { ok: true as const };
    };
    const rs = await Promise.all(Array.from({ length: 8 }, () => requestCode("+919812345678", T0, send)));
    assert.equal(rs.filter((r) => r.ok).length, 1);
    assert.equal(sends, 1);
    assert.equal((await prisma.otpCode.findUniqueOrThrow({ where: { phone: "919812345678" } })).sendCount, 1);
  });

  test("refused requests leave the code already sent, and its tries, alone", async () => {
    const o = outbox();
    await requestCode("+919812345678", T0, o.send);
    const sent = await prisma.otpCode.findUniqueOrThrow({ where: { phone: "919812345678" } });
    await verifyCode("+919812345678", o.codes.get("919812345678") === "000000" ? "111111" : "000000", at(5));
    await Promise.all([requestCode("+919812345678", at(10), o.send), requestCode("+919812345678", at(10), o.send)]);
    const row = await prisma.otpCode.findUniqueOrThrow({ where: { phone: "919812345678" } });
    assert.deepEqual([row.codeHash, row.attempts, row.sendCount], [sent.codeHash, 1, 1]);
  });

  test("a site-wide hourly ceiling stops mass sends to many numbers", async () => {
    await prisma.otpCode.create({
      data: { phone: "910000000001", codeHash: "x", expiresAt: at(600), sentAt: T0, windowStart: T0, sendCount: 10_000 },
    });
    let sends = 0;
    const send = async () => {
      sends++;
      return { ok: true as const };
    };
    const r = await requestCode("+919812345678", at(60), send);
    assert.equal(r.ok, false);
    assert.match(!r.ok ? r.error : "", /WhatsApp/);
    assert.equal(sends, 0);
    assert.equal((await requestCode("+919812345678", at(3700), send)).ok, true, "a new hour");
  });

  test("a failed send is reported, not silently swallowed", async () => {
    const r = await requestCode("+919812345678", T0, async () => ({ ok: false as const, error: "no template" }));
    assert.equal(r.ok, false);
  });
});

describe("verifying a code", () => {
  test("the right code signs in and creates the account (same flow for new and known numbers)", async () => {
    const o = outbox();
    await requestCode("+919812345678", T0, o.send);
    const r = await verifyCode("98123 45678", o.codes.get("919812345678")!, at(60));
    assert.equal(r.ok, true);
    const c = await prisma.customer.findUniqueOrThrow({ where: { phone: "919812345678" } });
    assert.equal(r.ok && r.customerId, c.id);
    assert.equal(await prisma.otpCode.count(), 0, "a code works once");
    const again = await verifyCode("+919812345678", o.codes.get("919812345678")!, at(61));
    assert.equal(again.ok, false);
  });

  test("wrong codes count down, and five wrong tries lock the code", async () => {
    const o = outbox();
    await requestCode("+919812345678", T0, o.send);
    const right = o.codes.get("919812345678")!;
    const wrong = right === "000000" ? "111111" : "000000";
    const first = await verifyCode("+919812345678", wrong, at(10));
    assert.match(!first.ok ? first.error : "", /4 tries left/);
    for (let i = 0; i < 4; i++) await verifyCode("+919812345678", wrong, at(11 + i));
    const locked = await verifyCode("+919812345678", right, at(20));
    assert.equal(locked.ok, false, "even the right code, once locked");
    assert.match(!locked.ok ? locked.error : "", /new code/);
  });

  test("parallel guesses can't exceed the five tries", async () => {
    const o = outbox();
    await requestCode("+919812345678", T0, o.send);
    const right = o.codes.get("919812345678")!;
    const guesses = Array.from({ length: 20 }, (_, i) => String((Number(right) + i + 1) % 1_000_000).padStart(6, "0"));
    await Promise.all(guesses.map((g) => verifyCode("+919812345678", g, at(10))));
    const row = await prisma.otpCode.findUniqueOrThrow({ where: { phone: "919812345678" } });
    assert.equal(row.attempts, 5);
  });

  test("an expired code is refused", async () => {
    const o = outbox();
    await requestCode("+919812345678", T0, o.send);
    const r = await verifyCode("+919812345678", o.codes.get("919812345678")!, at(11 * 60));
    assert.equal(r.ok, false);
    assert.match(!r.ok ? r.error : "", /expired/);
  });

  test("no code requested", async () => {
    const r = await verifyCode("+919812345678", "123456", T0);
    assert.equal(r.ok, false);
  });
});

describe("accounts from before website sign-in existed", () => {
  test("a guest who booked before accounts existed (backfilled customer) can sign in", async () => {
    await seedRooms([{ id: "101" }]);
    const legacy = await prisma.booking.create({
      data: {
        roomId: "101", guestName: "Old Guest", guestPhone: "919812345678", guests: 1,
        checkInAt: new Date("2026-09-01T07:30:00Z"), checkOutAt: new Date("2026-09-02T05:30:00Z"),
        ratePerNight: 1000, nights: 1, total: 1000, advancePaid: 500, status: "CONFIRMED", source: "WHATSAPP",
      },
    });
    const sql = readFileSync("prisma/migrations/20260925115142_accounts_payments/migration.sql", "utf8");
    for (const stmt of sql.slice(sql.indexOf("-- Backfill")).split(";").map((s) => s.trim()).filter(Boolean)) {
      await prisma.$executeRawUnsafe(stmt);
    }
    const customer = await prisma.customer.findUniqueOrThrow({ where: { phone: "919812345678" } });
    assert.match(customer.id, /^cust_[0-9a-f]{32}$/);
    assert.equal(customer.name, "Old Guest");
    assert.equal((await prisma.booking.findUniqueOrThrow({ where: { id: legacy.id } })).customerId, customer.id);
    assert.equal(await prisma.payment.count({ where: { bookingId: legacy.id, status: "ACKNOWLEDGED", amount: 500 } }), 1);

    const o = outbox();
    await requestCode("+919812345678", T0, o.send);
    const r = await verifyCode("+919812345678", o.codes.get("919812345678")!, at(30));
    assert.equal(r.ok && r.customerId, customer.id);
    assert.equal(verifyGuestSession(signGuestSession(customer.id)), customer.id, "the backfilled id is a valid session");
  });
});

describe("sign-in availability", () => {
  test("production needs the WhatsApp code template; local dev shows the code instead", () => {
    const e = process.env as Record<string, string | undefined>;
    const before = { node: e["NODE_ENV"], tpl: e["WA_TPL_OTP"] };
    try {
      e["WA_TPL_OTP"] = "";
      e["NODE_ENV"] = "production";
      assert.equal(signInAvailable(), false);
      e["WA_TPL_OTP"] = "coral_otp";
      assert.equal(signInAvailable(), true);
      e["WA_TPL_OTP"] = "";
      e["NODE_ENV"] = "development";
      assert.equal(signInAvailable(), true);
    } finally {
      for (const [k, v] of [["NODE_ENV", before.node], ["WA_TPL_OTP", before.tpl]] as const) {
        if (v === undefined) delete e[k];
        else e[k] = v;
      }
    }
  });
});

describe("guest sessions", () => {
  test("sign, verify, expiry, tampering, and no mixing with admin tokens", () => {
    const t0 = Date.parse("2026-10-01T00:00:00Z");
    const token = signGuestSession("ckcustomer0000000001", t0);
    assert.equal(verifyGuestSession(token, t0 + 1000), "ckcustomer0000000001");
    assert.equal(verifyGuestSession(token, t0 + (GUEST_MAX_AGE + 60) * 1000), null);
    const [id, exp, sig] = token.split(".");
    assert.equal(verifyGuestSession(`ckcustomer0000000002.${exp}.${sig}`, t0), null);
    assert.equal(verifyGuestSession(`${id}.${Number(exp) + 1}.${sig}`, t0), null);
    for (const bad of [undefined, "", "a.b", "a.b.c.d"]) assert.equal(verifyGuestSession(bad, t0), null);
    assert.equal(verifyGuestSession(signSession(t0), t0), null, "an admin token isn't a guest token");
    assert.equal(verifySession(token, t0), false, "a guest token isn't an admin token");
  });
});
