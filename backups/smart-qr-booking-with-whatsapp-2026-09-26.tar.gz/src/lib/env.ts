/**
 * Server-side configuration from environment variables.
 * Read lazily (getters) so a missing variable only fails the feature that needs it —
 * e.g. the site builds and browses fine without WhatsApp credentials.
 */

function need(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`${name} is not set`);
  return v;
}
const opt = (name: string): string => process.env[name] ?? "";

const digits = (s: string) => s.replace(/\D/g, "");

export const env = {
  get adminPassword() { return need("ADMIN_PASSWORD"); },
  get sessionSecret() { return need("SESSION_SECRET"); },

  get waAccessToken() { return need("WA_ACCESS_TOKEN"); },
  get waPhoneNumberId() { return need("WA_PHONE_NUMBER_ID"); },
  get waAppSecret() { return need("WA_APP_SECRET"); },
  get waVerifyToken() { return need("WA_VERIFY_TOKEN"); },
  get waApiBase() { return (opt("WA_API_BASE") || "https://graph.facebook.com/v23.0").replace(/\/$/, ""); },
  /** Approved template used to reach someone outside the 24h window (one text variable + one quick-reply button). */
  get waTemplateNotify() { return opt("WA_TPL_NOTIFY"); },
  /** Approved template for the last-day nudge (two text variables + two quick-reply buttons). */
  get waTemplateLastDay() { return opt("WA_TPL_LAST_DAY"); },
  get waTemplateLang() { return opt("WA_TPL_LANG") || "en"; },
  /** Approved AUTHENTICATION template for website sign-in codes (copy-code button). */
  get waTemplateOtp() { return opt("WA_TPL_OTP"); },

  /** Owner / front-desk WhatsApp numbers, digits only. */
  get ownerNumbers(): string[] {
    return opt("OWNER_WHATSAPP").split(",").map(digits).filter(Boolean);
  },
  get upiId() { return opt("UPI_ID"); },
  get upiPayeeName() { return opt("UPI_PAYEE_NAME") || "The Coral Courtyard"; },
  get holdMinutes(): number {
    const n = Number(opt("HOLD_MINUTES"));
    return Number.isFinite(n) && n > 0 ? n : 120;
  },
  get cronSecret() { return need("CRON_SECRET"); },

  /** Web Push (owner app notifications). Generate once: `npx web-push generate-vapid-keys`. */
  get vapidPublicKey() { return opt("NEXT_PUBLIC_VAPID_PUBLIC_KEY"); },
  get vapidPrivateKey() { return opt("VAPID_PRIVATE_KEY"); },
  /** Contact for the push services: the site URL (https) unless VAPID_SUBJECT says otherwise. */
  get vapidSubject() {
    const site = opt("NEXT_PUBLIC_BASE_URL");
    return opt("VAPID_SUBJECT") || (site.startsWith("https://") ? site : "mailto:owner@example.com");
  },
};
