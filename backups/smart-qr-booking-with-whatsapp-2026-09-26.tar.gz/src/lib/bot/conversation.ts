/** Chat state persistence: one row per WhatsApp number. */
import { prisma } from "@/lib/db";
import type { ConvState, Draft, Stage } from "./types";

export async function loadConv(phone: string): Promise<ConvState> {
  const row = await prisma.conversation.findUnique({ where: { phone } });
  if (!row) return { phone, roomId: null, stage: "browsing", draft: {} };
  return { phone, roomId: row.roomId, stage: row.stage as Stage, draft: (row.draft ?? {}) as Draft };
}

export async function saveConv(conv: ConvState): Promise<void> {
  const data = { roomId: conv.roomId, stage: conv.stage, draft: conv.draft };
  await prisma.conversation.upsert({
    where: { phone: conv.phone },
    create: { phone: conv.phone, ...data },
    update: data,
  });
}
