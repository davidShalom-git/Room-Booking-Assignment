/**
 * Booking on the website: the same engine and payment ledger as WhatsApp, for a signed-in guest
 * (an account is just their phone number). The owner hears about website payments on WhatsApp,
 * exactly like chat payments.
 */
import { prisma } from "@/lib/db";
import type { Booking, Payment } from "@/generated/prisma/client";
import * as engine from "@/lib/engine";
import { bad, type BookingRow, type Result } from "@/lib/engine";
import * as payments from "@/lib/payments";
import { paymentView, stayView, toView } from "@/lib/bot/ports-prisma";
import * as C from "@/lib/bot/copy";
import { ownerClaimAlerts, toOwners } from "@/lib/notify";
import { deliver } from "@/lib/wa/deliver";
import { normalizePhone, validPhone } from "@/lib/phone";
import { todayISO } from "@/lib/pricing";

export type WebBookingInput = {
  roomId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  name: string;
  /** Another number to reach them on; blank = their account (WhatsApp) number. */
  contactPhone: string;
};

/** A guest's unpaid new-stay hold, if they have one. */
export async function pendingHoldFor(phone: string, now: Date = new Date()): Promise<BookingRow | null> {
  await engine.sweepHolds(now);
  return prisma.booking.findFirst({
    where: { guestPhone: phone, status: "PENDING", parentId: null },
    include: engine.withRoom,
    orderBy: { createdAt: "desc" },
  });
}

export async function createWebBooking(customerId: string, i: WebBookingInput, now: Date = new Date()): Promise<Result<BookingRow>> {
  const customer = await prisma.customer.findUnique({ where: { id: customerId } });
  if (!customer) return bad("NOT_FOUND", "Please sign in again.");
  const name = i.name.trim();
  if (name.length < 2) return bad("INVALID", "Please enter the name for the booking.");
  let contact = "";
  if (i.contactPhone.trim()) {
    contact = normalizePhone(i.contactPhone);
    if (!validPhone(contact)) return bad("INVALID", "That contact number doesn't look right — include the country code.");
  }
  if (i.checkIn < todayISO(now)) return bad("INVALID", "Check-in can't be in the past.");

  const held = await pendingHoldFor(customer.phone, now);
  if (held) {
    return bad("INVALID", `You already have Room ${held.roomId} on hold (${engine.bookingRef(held)}). Pay for it or cancel it first.`);
  }
  if (!customer.name) await prisma.customer.update({ where: { id: customer.id }, data: { name: name.slice(0, 80) } });
  return engine.createBooking({
    roomId: i.roomId,
    guestName: name,
    guestPhone: customer.phone,
    contactPhone: contact || undefined,
    guests: i.guests,
    checkIn: i.checkIn,
    checkOut: i.checkOut,
    status: "PENDING",
    source: "WEB",
    now,
  });
}

/**
 * What the pay page offers. "pay": UPI + the UTR box, while the hold is live — or after it lapsed
 * if the payment is already with the desk. "expired": a lapsed hold nobody has paid for; only the
 * UTR box, for money already sent (the room may be gone). "none": nothing is owed.
 */
export function payState(
  b: Pick<Booking, "status" | "holdExpiresAt">,
  owed: Pick<Payment, "status"> | null,
): "pay" | "expired" | "none" {
  if (!owed) return "none";
  if (b.status === "PENDING") return "pay";
  if (b.status === "CANCELLED" && b.holdExpiresAt) return owed.status === "CLAIMED" ? "pay" : "expired";
  return "none";
}

/** The UTR from the pay page: the payment is claimed and the owner gets it to acknowledge. */
export async function claimFromWeb(bookingId: string, utr: string, now: Date = new Date()) {
  const r = await payments.claimPayment(bookingId, utr, now);
  if (!r.ok) return r;
  const stay = r.value.kind === "EXTENSION" ? await engine.stayOf(bookingId) : null;
  await deliver(ownerClaimAlerts(paymentView(r.value), stay ? stayView(stay) : null, r.value.duplicateRef), now);
  return r;
}

/** A guest cancels their own unpaid hold from their account. */
export async function cancelWebHold(customerId: string, bookingId: string): Promise<Result<BookingRow>> {
  const [customer, b] = await Promise.all([
    prisma.customer.findUnique({ where: { id: customerId } }),
    engine.getBooking(bookingId),
  ]);
  if (!customer || !b || b.guestPhone !== customer.phone) return bad("NOT_FOUND", "Booking not found.");
  if (b.status !== "PENDING") {
    return bad("INVALID", "Only a booking that's still waiting for payment can be cancelled here. For anything else, message us on WhatsApp.");
  }
  const owed = await payments.openPayment(b.id);
  const r = await engine.cancelBooking(b.id);
  if (r.ok && owed?.status === "CLAIMED") await deliver(toOwners(C.ownerClaimCancelledByGuest(toView(r.value))));
  return r;
}

export type GuestStay = {
  root: BookingRow;
  /** The stay's bookings in order: the first one, then extensions / moves (cancelled ones left out). */
  parts: BookingRow[];
  payments: Payment[];
  status: "PENDING" | "CONFIRMED" | "CANCELLED";
  total: number;
  paid: number;
  /** A part waiting for payment, if any (links to its pay page). */
  awaiting: BookingRow | null;
};

/** Everything a signed-in guest has booked, newest first. */
export async function guestStays(customerId: string, now: Date = new Date()): Promise<GuestStay[]> {
  const customer = await prisma.customer.findUnique({ where: { id: customerId } });
  if (!customer) return [];
  await engine.sweepHolds(now);
  const withPayments = { room: true, payments: { orderBy: { createdAt: "asc" as const } } };
  const roots = await prisma.booking.findMany({
    where: { parentId: null, OR: [{ customerId }, { guestPhone: customer.phone }] },
    include: withPayments,
    orderBy: { checkInAt: "desc" },
  });
  const segments = await prisma.booking.findMany({
    where: { parentId: { in: roots.map((r) => r.id) }, status: { not: "CANCELLED" } },
    include: withPayments,
    orderBy: { checkInAt: "asc" },
  });
  return roots.map((root) => {
    const parts = [root, ...segments.filter((s) => s.parentId === root.id)];
    const live = parts.filter((p) => p.status !== "CANCELLED");
    return {
      root,
      parts,
      payments: parts.flatMap((p) => p.payments),
      status: root.status,
      total: live.reduce((s, p) => s + p.total, 0),
      paid: live.reduce((s, p) => s + p.advancePaid, 0),
      awaiting: live.find((p) => p.status === "PENDING") ?? null,
    };
  });
}
