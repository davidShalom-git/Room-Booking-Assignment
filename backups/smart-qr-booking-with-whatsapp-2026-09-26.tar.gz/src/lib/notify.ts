/**
 * Messages that go out when something happens outside a chat (the website, the owner console):
 * the same texts and buttons the bot uses, delivered through the 24h-window-aware deliver().
 */
import { env } from "@/lib/env";
import * as C from "@/lib/bot/copy";
import { OWNER_PUSH, type Out, type PaymentView, type StayView } from "@/lib/bot/types";

/** The owner app (push) plus every owner WhatsApp number. */
const ownerRecipients = () => [OWNER_PUSH, ...env.ownerNumbers];

/** "Customer X paid ₹Y for Room Z, UTR …" with Acknowledge / Not received, to every owner number. */
export function ownerClaimAlerts(p: PaymentView, stay: StayView | null, duplicateRef: string | null): Out[] {
  return ownerRecipients().map((to) => ({
    to,
    text: C.ownerPaymentClaim(p, stay, duplicateRef),
    template: "owner_alert" as const,
    buttons: [
      { id: `ack:${p.id}`, title: "Acknowledge" },
      { id: `nack:${p.id}`, title: "Not received" },
    ],
  }));
}

export const toOwners = (text: string): Out[] =>
  ownerRecipients().map((to) => ({ to, text, template: "owner_alert" as const }));
