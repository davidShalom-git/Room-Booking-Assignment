import { cookies } from "next/headers";
import { prisma } from "@/lib/db";
import { GUEST_COOKIE, verifyGuestSession } from "@/lib/session";

/** The signed-in guest (their account), or null. */
export async function currentGuest() {
  const id = verifyGuestSession((await cookies()).get(GUEST_COOKIE)?.value);
  return id ? prisma.customer.findUnique({ where: { id } }) : null;
}

/** Only same-site paths: never another host, never a protocol-relative URL. */
export const safeNext = (n: string | null | undefined, fallback = "/account") =>
  n && /^\/(?![/\\])[^\s\\]*$/.test(n) ? n : fallback;
