/**
 * Website sign-in with a code sent on WhatsApp — no passwords, no sign-up form. The account is
 * the phone number (created on first sign-in or first booking). Only an HMAC of each code is
 * stored; codes expire after 10 minutes, allow 5 tries, and can be requested once a minute and
 * five times an hour per number. The same answers are given whether or not a number is known.
 */
import { createHmac, randomInt } from "node:crypto";
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { ensureCustomer } from "@/lib/engine";
import { normalizePhone, validPhone } from "@/lib/phone";
import { safeEqual } from "@/lib/secure";
import { otpTemplatePayload, sendPayload } from "@/lib/wa/client";

const CODE_TTL_MS = 10 * 60_000;
const MAX_ATTEMPTS = 5;
const RESEND_GAP_MS = 60_000;
const PER_HOUR = 5;
const HOUR_MS = 3_600_000;
/** Codes sent site-wide per hour (not counting ones already used), so nobody can spam numbers through us. */
const ALL_PER_HOUR = 100;

const hash = (phone: string, code: string) =>
  createHmac("sha256", process.env["SESSION_SECRET"] ?? "").update(`otp:${phone}:${code}`).digest("hex");

export type Sender = (phone: string, code: string) => Promise<{ ok: true; devCode?: string } | { ok: false; error: string }>;

/** Codes can be sent: the WA_TPL_OTP template is set up, or this is local dev (the code is shown instead). */
export const signInAvailable = () => !!env.waTemplateOtp || process.env.NODE_ENV !== "production";

/** Sends through the WA_TPL_OTP template. Without one: local dev shows the code; production refuses. */
export const whatsappSender: Sender = async (phone, code) => {
  const tpl = env.waTemplateOtp;
  if (!tpl) {
    if (signInAvailable()) {
      console.info(`[signin] code for +${phone}: ${code} (WA_TPL_OTP not set — dev only)`);
      return { ok: true, devCode: code };
    }
    return { ok: false, error: "Sign-in by code isn't available right now. Please message us on WhatsApp to book." };
  }
  return (await sendPayload(otpTemplatePayload(phone, code, tpl, env.waTemplateLang)))
    ? { ok: true }
    : { ok: false, error: "We couldn't send the code just now. Please try again in a minute." };
};

export type RequestResult = { ok: true; phone: string; devCode?: string } | { ok: false; error: string };

export async function requestCode(raw: string, now: Date = new Date(), send: Sender = whatsappSender): Promise<RequestResult> {
  const phone = normalizePhone(raw);
  if (!validPhone(phone)) return { ok: false, error: "Enter your WhatsApp number with the country code, e.g. +91 98450 21133." };

  const t = now.getTime();
  const hourAgo = new Date(t - HOUR_MS);
  // ponytail: approximate (a window that started just over an hour ago drops out early) — a ceiling, not a meter.
  const recent = await prisma.otpCode.aggregate({ where: { windowStart: { gt: hourAgo } }, _sum: { sendCount: true } });
  if ((recent._sum.sendCount ?? 0) >= ALL_PER_HOUR) {
    return { ok: false, error: "We're getting a lot of sign-in requests right now. Please try again later, or message us on WhatsApp to book." };
  }

  // Check the limits and store the new code in one statement, so parallel requests can't slip
  // past them: a refused request changes nothing (the code already sent, and its tries, stay).
  const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
  const stored = await prisma.$queryRaw<{ phone: string }[]>`
    INSERT INTO "OtpCode" ("phone", "codeHash", "expiresAt", "attempts", "sentAt", "windowStart", "sendCount")
    VALUES (${phone}, ${hash(phone, code)}, ${new Date(t + CODE_TTL_MS)}, 0, ${now}, ${now}, 1)
    ON CONFLICT ("phone") DO UPDATE SET
      "codeHash" = EXCLUDED."codeHash",
      "expiresAt" = EXCLUDED."expiresAt",
      "attempts" = 0,
      "sentAt" = EXCLUDED."sentAt",
      "windowStart" = CASE WHEN "OtpCode"."windowStart" <= ${hourAgo} THEN EXCLUDED."sentAt" ELSE "OtpCode"."windowStart" END,
      "sendCount" = CASE WHEN "OtpCode"."windowStart" <= ${hourAgo} THEN 1 ELSE "OtpCode"."sendCount" + 1 END
    WHERE "OtpCode"."sentAt" <= ${new Date(t - RESEND_GAP_MS)}
      AND ("OtpCode"."windowStart" <= ${hourAgo} OR "OtpCode"."sendCount" < ${PER_HOUR})
    RETURNING "phone"`;
  if (stored.length === 0) {
    const prev = await prisma.otpCode.findUnique({ where: { phone } });
    const since = prev ? t - prev.sentAt.getTime() : 0;
    return since < RESEND_GAP_MS
      ? { ok: false, error: `Please wait ${Math.ceil((RESEND_GAP_MS - since) / 1000)} seconds before asking for another code.` }
      : { ok: false, error: "Too many codes requested. Please try again in an hour." };
  }

  const sent = await send(phone, code);
  if (!sent.ok) return { ok: false, error: sent.error };
  return { ok: true, phone, ...(sent.devCode ? { devCode: sent.devCode } : {}) };
}

export type VerifyResult = { ok: true; customerId: string } | { ok: false; error: string };

export async function verifyCode(raw: string, codeRaw: string, now: Date = new Date()): Promise<VerifyResult> {
  const phone = normalizePhone(raw);
  const code = codeRaw.replace(/\D/g, "");
  // Spend a try first (atomically), so parallel guesses can't exceed the limit.
  const spent = await prisma.otpCode.updateMany({
    where: { phone, attempts: { lt: MAX_ATTEMPTS }, expiresAt: { gt: now } },
    data: { attempts: { increment: 1 } },
  });
  const row = await prisma.otpCode.findUnique({ where: { phone } });
  if (spent.count === 0 || !row) {
    if (!row || row.expiresAt <= now) return { ok: false, error: "That code has expired. Ask for a new one." };
    return { ok: false, error: "Too many wrong tries. Ask for a new code." };
  }
  if (code.length !== 6 || !safeEqual(hash(phone, code), row.codeHash)) {
    const left = MAX_ATTEMPTS - row.attempts;
    return {
      ok: false,
      error: left > 0 ? `That code isn't right. ${left} ${left === 1 ? "try" : "tries"} left.` : "Too many wrong tries. Ask for a new code.",
    };
  }
  await prisma.otpCode.deleteMany({ where: { phone } });
  const customer = await ensureCustomer(phone);
  return { ok: true, customerId: customer.id };
}
