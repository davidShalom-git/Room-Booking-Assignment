/**
 * The website chat: the WhatsApp bot, on the lodge's own website — no Meta account needed.
 *
 * A chat is a random key ("web:<22 chars>") kept in the visitor's cookie. The bot runs exactly as
 * on WhatsApp (step.ts); its replies are stored as ChatMessage rows (deliver.ts) and the chat
 * window polls for them. A booking made here remembers its chat (Booking.chatKey), so the owner's
 * confirmation — from the owner app, the console or WhatsApp — comes back into the same chat.
 */
import { randomBytes } from "node:crypto";
import { prisma } from "@/lib/db";
import { step } from "@/lib/bot/step";
import { loadConv, saveConv } from "@/lib/bot/conversation";
import { prismaPorts } from "@/lib/bot/ports-prisma";
import type { InEvent, Out, Ports, Row } from "@/lib/bot/types";
import { deliver } from "@/lib/wa/deliver";
import { oneAtATime } from "@/lib/wa/handle";

const HOUR_MS = 3_600_000;

export const newChatKey = () => `web:${randomBytes(16).toString("base64url")}`;
export const isChatKey = (k: string | null | undefined): k is string => !!k && /^web:[A-Za-z0-9_-]{22}$/.test(k);

/**
 * Fixed-window counter: true while `key` has been hit at most `limit` times in the window.
 * One statement, so parallel requests can't slip past it.
 */
export async function hit(key: string, limit: number, windowMs: number, now: Date = new Date()): Promise<boolean> {
  const since = new Date(now.getTime() - windowMs);
  const rows = await prisma.$queryRaw<{ count: number }[]>`
    INSERT INTO "RateLimit" ("key", "windowStart", "count") VALUES (${key}, ${now}, 1)
    ON CONFLICT ("key") DO UPDATE SET
      "windowStart" = CASE WHEN "RateLimit"."windowStart" <= ${since} THEN EXCLUDED."windowStart" ELSE "RateLimit"."windowStart" END,
      "count" = CASE WHEN "RateLimit"."windowStart" <= ${since} THEN 1 ELSE "RateLimit"."count" + 1 END
    RETURNING "count"`;
  return Number(rows[0]?.count ?? limit + 1) <= limit;
}

/**
 * The bot's ports for a website visitor: no account lookups by phone (a typed number proves
 * nothing), and at most 3 new holds an hour from one network — anyone can open a chat, and a
 * hold blocks a room until it lapses.
 */
export function webPorts(base: Ports, ip: string): Ports {
  return {
    ...base,
    customer: async () => null,
    createHold: async (i) =>
      (await hit(`hold:${ip}`, 3, HOUR_MS, base.now()))
        ? base.createHold(i)
        : {
            ok: false,
            code: "LIMIT",
            message: "Too many bookings from this network in the last hour — please try again later, or message us on WhatsApp.",
          },
  };
}

export type ChatEvent = { text: string } | { button: string; title: string };
export type ChatMsg = {
  id: number;
  fromGuest: boolean;
  text: string;
  buttons: { id: string; title: string }[] | null;
  list: { button: string; rows: Row[] } | null;
  at: string;
};

/** One message from the visitor: stored, answered by the bot, answer stored. */
export async function chatSend(
  key: string,
  ev: ChatEvent,
  opts: { ip: string; now?: Date; ports?: Ports },
): Promise<{ ok: true } | { ok: false; error: string }> {
  if (!isChatKey(key)) return { ok: false, error: "This chat has expired — please reload the page." };
  const text = ("text" in ev ? ev.text : ev.title).trim();
  if (!text || text.length > 1000) return { ok: false, error: "Please type a message (up to 1,000 characters)." };
  if ("button" in ev && (!ev.button || ev.button.length > 100)) return { ok: false, error: "That option isn't valid." };

  const now = opts.now ?? new Date();
  if (!(await hit(`chat:${key}`, 20, 60_000, now)) || !(await hit(`ip:${opts.ip}`, 60, 60_000, now))) {
    return { ok: false, error: "You're sending messages very fast — please wait a few seconds." };
  }

  const event: InEvent = "text" in ev ? { kind: "text", from: key, text } : { kind: "button", from: key, id: ev.button };
  const ports = opts.ports ?? webPorts(prismaPorts(), opts.ip);
  await oneAtATime(key, async () => {
    await prisma.chatMessage.create({ data: { chat: key, fromGuest: true, text } });
    const r = await step(await loadConv(key), event, ports);
    await deliver(r.out, now);
    await saveConv(r.conv);
  });
  return { ok: true };
}

/** The chat's messages after `after` (a message id), oldest first. */
export async function chatMessages(key: string, after = 0): Promise<ChatMsg[]> {
  if (!isChatKey(key)) return [];
  const rows = await prisma.chatMessage.findMany({
    where: { chat: key, id: { gt: after } },
    orderBy: { id: "asc" },
    take: 200,
  });
  return rows.map((m) => ({
    id: m.id,
    fromGuest: m.fromGuest,
    text: m.text,
    buttons: (m.buttons as Out["buttons"]) ?? null,
    list: (m.list as Out["list"]) ?? null,
    at: m.createdAt.toISOString(),
  }));
}
