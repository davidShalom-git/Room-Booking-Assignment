/** Process inbound WhatsApp messages: dedupe, load the chat, run the bot, reply, save. */
import { prisma } from "@/lib/db";
import { step } from "@/lib/bot/step";
import { loadConv, saveConv } from "@/lib/bot/conversation";
import { prismaPorts } from "@/lib/bot/ports-prisma";
import type { InEvent, Out, Ports } from "@/lib/bot/types";
import { deliver, queuePending, takePending } from "./deliver";
import { messagePayload, sendPayload } from "./client";

/**
 * Returns false if any message failed; the webhook then answers 500 so Meta re-delivers, and
 * the failed message's dedupe marker is removed so the retry is processed.
 */
export async function handleInbound(
  msgs: { id: string; event: InEvent }[],
  opts: { ports?: Ports; now?: () => Date } = {},
): Promise<boolean> {
  const ports = opts.ports ?? prismaPorts();
  const now = opts.now ?? (() => new Date());
  let allOk = true;
  for (const m of msgs) {
    try {
      if (!(await claim(m.id))) continue;
    } catch (e) {
      console.error("[wa] could not record message", m.id, e);
      allOk = false;
      continue;
    }
    try {
      await oneAtATime(m.event.from, () => processOne(m.event, ports, now()));
    } catch (e) {
      console.error("[wa] failed to handle message", m.id, e);
      allOk = false;
      await prisma.processedMessage.delete({ where: { id: m.id } }).catch(() => undefined);
    }
  }
  return allOk;
}

/** Meta re-delivers webhooks: the first insert of a message id wins, repeats are skipped. */
async function claim(id: string): Promise<boolean> {
  try {
    await prisma.processedMessage.create({ data: { id } });
    return true;
  } catch (e) {
    if ((e as { code?: string }).code === "P2002") return false;
    throw e;
  }
}

/**
 * Serialize work per WhatsApp number across all server instances: a Postgres advisory lock
 * held for the length of a transaction. Two taps from one chat (a double tap, or Meta
 * re-delivering while the first copy is still running) then see each other's result instead
 * of racing on the same conversation.
 */
export async function oneAtATime<T>(phone: string, work: () => Promise<T>): Promise<T> {
  return prisma.$transaction(
    async (tx) => {
      await tx.$queryRaw`SELECT 1 AS locked FROM pg_advisory_xact_lock(4242, hashtext(${phone}))`;
      return work();
    },
    { maxWait: 10_000, timeout: 25_000 },
  );
}

async function processOne(ev: InEvent, ports: Ports, now: Date) {
  await prisma.conversation.upsert({
    where: { phone: ev.from },
    create: { phone: ev.from, lastInboundAt: now },
    update: { lastInboundAt: now },
  });

  // They just wrote in, so the window is open: deliver anything that was waiting for it.
  // Anything that still fails to send goes back in the queue rather than being dropped.
  const pending = await takePending(ev.from);
  const failed: Out[] = [];
  for (const out of pending) if (!(await sendPayload(messagePayload(out)))) failed.push(out);
  for (const out of failed) await queuePending(out);
  if (ev.kind === "button" && ev.id === "resend") {
    if (pending.length === 0) {
      await sendPayload(messagePayload({ to: ev.from, text: "You're all caught up — nothing new right now." }));
    }
    return;
  }

  const conv = await loadConv(ev.from);
  const r = await step(conv, ev, ports);
  // Reply before saving: if the save then fails, Meta's retry replays the step, and every step is
  // safe to replay (holds are resumed, owner taps are idempotent) — whereas a save followed by a
  // failed reply would leave the guest or owner never hearing about something that happened.
  await deliver(r.out, now);
  await saveConv(r.conv);
}
