/**
 * Getting a message to someone, within WhatsApp's rules.
 *
 * A business may message a number freely only within 24h of that number's last message
 * (the "customer service window"). Outside it, only approved templates go through. The owner
 * rarely writes to the business number, so owner alerts are usually outside the window.
 *
 *   inside the window  -> send the message as is
 *   last-day nudge     -> the last-day template, if configured
 *   anything else      -> queue it on the recipient's conversation (sent the moment they next
 *                         write in, see handle.ts) and ping them with the notify template
 */
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { OWNER_PUSH, type Out } from "@/lib/bot/types";
import { sendOwnerPush } from "@/lib/push";
import { lastDayTemplatePayload, messagePayload, notifyTemplatePayload, sendPayload } from "./client";

/** 24h, minus a margin for clock skew and slow sends. */
export const WINDOW_MS = 24 * 3_600_000 - 10 * 60_000;

export async function deliver(outs: Out[], now: Date = new Date()): Promise<void> {
  for (const out of outs) {
    try {
      if (out.to.startsWith("web:")) await saveChatMessage(out);
      else if (out.to === OWNER_PUSH) await sendOwnerPush(out);
      else await deliverOne(out, now);
    } catch (e) {
      console.error("[wa] deliver failed", out.to, e);
    }
  }
}

/** A website chat reads its messages from the database (see lib/web-chat.ts). */
async function saveChatMessage(out: Out) {
  await prisma.chatMessage.create({
    data: { chat: out.to, fromGuest: false, text: out.text, buttons: out.buttons ?? undefined, list: out.list ?? undefined },
  });
}

async function deliverOne(out: Out, now: Date) {
  const conv = await prisma.conversation.findUnique({ where: { phone: out.to }, select: { lastInboundAt: true } });
  const open = !!conv?.lastInboundAt && now.getTime() - conv.lastInboundAt.getTime() < WINDOW_MS;
  if (open) {
    // A business alert that fails to go out (Graph outage) waits for the recipient's next message.
    if (!(await sendPayload(messagePayload(out))) && out.template) await queuePending(out);
    return;
  }
  if (out.template === "last_day" && env.waTemplateLastDay) {
    await sendPayload(lastDayTemplatePayload(out, env.waTemplateLastDay, env.waTemplateLang));
    return;
  }
  await queuePending(out);
  if (env.waTemplateNotify) {
    await sendPayload(notifyTemplatePayload(out, env.waTemplateNotify, env.waTemplateLang));
  } else {
    console.warn(`[wa] ${out.to} hasn't written in the last 24h and WA_TPL_NOTIFY is not set; message queued until they do.`);
  }
}

// ponytail: unbounded queue per number; cap it if someone can go weeks without ever writing in.
export async function queuePending(out: Out) {
  const json = JSON.stringify([out]);
  await prisma.$executeRaw`
    INSERT INTO "Conversation" ("phone", "pendingOut", "updatedAt")
    VALUES (${out.to}, ${json}::jsonb, now())
    ON CONFLICT ("phone") DO UPDATE
      SET "pendingOut" = "Conversation"."pendingOut" || EXCLUDED."pendingOut", "updatedAt" = now()`;
}

/** Atomically take (and clear) everything queued for a number. */
export async function takePending(phone: string): Promise<Out[]> {
  const rows = await prisma.$queryRaw<{ pending: unknown }[]>`
    WITH old AS (
      SELECT "phone", "pendingOut" FROM "Conversation" WHERE "phone" = ${phone} FOR UPDATE
    )
    UPDATE "Conversation" c SET "pendingOut" = '[]'::jsonb
    FROM old
    WHERE c."phone" = old."phone" AND jsonb_array_length(old."pendingOut") > 0
    RETURNING old."pendingOut" AS pending`;
  const p = rows[0]?.pending;
  const list = typeof p === "string" ? JSON.parse(p) : p;
  return Array.isArray(list) ? (list as Out[]) : [];
}
