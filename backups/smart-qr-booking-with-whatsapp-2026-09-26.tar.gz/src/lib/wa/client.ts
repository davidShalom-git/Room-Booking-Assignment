/** WhatsApp Cloud API: bot messages -> Graph API payloads, and the HTTP call that sends them. */
import { env } from "@/lib/env";
import type { Out } from "@/lib/bot/types";

type Payload = Record<string, unknown>;

const cut = (s: string, n: number) => (s.length <= n ? s : s.slice(0, n - 1) + "…");
/** Template variables may not contain newlines, tabs or runs of 4+ spaces. */
const flat = (s: string) => cut(s.replace(/\s*\n+\s*/g, " · ").replace(/\s{2,}/g, " ").trim(), 1000);

const base = (to: string) => ({ messaging_product: "whatsapp", recipient_type: "individual", to });

/** A normal (session) message: text, up to 3 reply buttons, or a list. */
export function messagePayload(out: Out): Payload {
  if (out.list && out.list.rows.length > 0) {
    return {
      ...base(out.to),
      type: "interactive",
      interactive: {
        type: "list",
        body: { text: cut(out.text, 1024) },
        action: {
          button: cut(out.list.button, 20),
          sections: [
            {
              title: "Options",
              rows: out.list.rows.slice(0, 10).map((r) => ({
                id: r.id,
                title: cut(r.title, 24),
                ...(r.description ? { description: cut(r.description, 72) } : {}),
              })),
            },
          ],
        },
      },
    };
  }
  if (out.buttons && out.buttons.length > 0) {
    return {
      ...base(out.to),
      type: "interactive",
      interactive: {
        type: "button",
        body: { text: cut(out.text, 1024) },
        action: {
          buttons: out.buttons.slice(0, 3).map((b) => ({ type: "reply", reply: { id: b.id, title: cut(b.title, 20) } })),
        },
      },
    };
  }
  return { ...base(out.to), type: "text", text: { body: cut(out.text, 4096), preview_url: false } };
}

/**
 * Generic "you have an update" template for someone outside the 24h window. Its one variable
 * carries the message; its quick-reply button ("Show options") brings back the full message.
 */
export function notifyTemplatePayload(out: Out, name: string, lang: string): Payload {
  return {
    ...base(out.to),
    type: "template",
    template: {
      name,
      language: { code: lang },
      components: [
        { type: "body", parameters: [{ type: "text", text: flat(out.text) }] },
        { type: "button", sub_type: "quick_reply", index: "0", parameters: [{ type: "payload", payload: "resend" }] },
      ],
    },
  };
}

/** Last-day nudge template: variables = (first name, check-out date); buttons = extend / check out. */
export function lastDayTemplatePayload(out: Out, name: string, lang: string): Payload {
  return {
    ...base(out.to),
    type: "template",
    template: {
      name,
      language: { code: lang },
      components: [
        { type: "body", parameters: (out.params ?? []).map((p) => ({ type: "text", text: flat(p) })) },
        ...(out.buttons ?? []).slice(0, 2).map((b, i) => ({
          type: "button",
          sub_type: "quick_reply",
          index: String(i),
          parameters: [{ type: "payload", payload: b.id }],
        })),
      ],
    },
  };
}

/** POST one message. Never throws: a failed send is logged and reported as false. */
export async function sendPayload(payload: Payload): Promise<boolean> {
  let url: string;
  let token: string;
  try {
    url = `${env.waApiBase}/${env.waPhoneNumberId}/messages`;
    token = env.waAccessToken;
  } catch (e) {
    console.error("[wa] not configured:", (e as Error).message);
    return false;
  }
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) {
      console.error("[wa] send failed", res.status, (await res.text()).slice(0, 500));
      return false;
    }
    return true;
  } catch (e) {
    console.error("[wa] send error", e);
    return false;
  }
}

/** Website sign-in code: Meta's authentication template (code in the body + copy-code button). */
export function otpTemplatePayload(to: string, code: string, name: string, lang: string): Payload {
  return {
    ...base(to),
    type: "template",
    template: {
      name,
      language: { code: lang },
      components: [
        { type: "body", parameters: [{ type: "text", text: code }] },
        { type: "button", sub_type: "url", index: "0", parameters: [{ type: "text", text: code }] },
      ],
    },
  };
}
