/** Turn a Meta webhook payload into bot events. Anything unrecognised is skipped, never thrown. */
import type { InEvent } from "@/lib/bot/types";

type Json = Record<string, unknown>;
const obj = (v: unknown): Json | null => (typeof v === "object" && v !== null ? (v as Json) : null);
const arr = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);
const str = (v: unknown): string | null => (typeof v === "string" ? v : null);

/** Message types that carry nothing for the bot to answer. */
const IGNORED = new Set(["reaction", "system", "ephemeral", "request_welcome"]);

export function parseInbound(body: unknown): { id: string; event: InEvent }[] {
  const out: { id: string; event: InEvent }[] = [];
  for (const entry of arr(obj(body)?.["entry"])) {
    for (const change of arr(obj(entry)?.["changes"])) {
      for (const raw of arr(obj(obj(change)?.["value"])?.["messages"])) {
        const m = obj(raw);
        const id = str(m?.["id"]);
        const from = str(m?.["from"])?.replace(/\D/g, "");
        const type = str(m?.["type"]);
        if (!m || !id || !from || !type || IGNORED.has(type)) continue;

        if (type === "text") {
          const text = str(obj(m["text"])?.["body"]);
          if (text !== null) out.push({ id, event: { kind: "text", from, text } });
        } else if (type === "interactive") {
          const i = obj(m["interactive"]);
          const reply = str(obj(i?.["button_reply"])?.["id"]) ?? str(obj(i?.["list_reply"])?.["id"]);
          if (reply) out.push({ id, event: { kind: "button", from, id: reply } });
        } else if (type === "button") {
          // Quick-reply button on a template message.
          const b = obj(m["button"]);
          const payload = str(b?.["payload"]);
          const text = str(b?.["text"]);
          if (payload) out.push({ id, event: { kind: "button", from, id: payload } });
          else if (text) out.push({ id, event: { kind: "text", from, text } });
        } else {
          out.push({ id, event: { kind: "media", from } });
        }
      }
    }
  }
  return out;
}
