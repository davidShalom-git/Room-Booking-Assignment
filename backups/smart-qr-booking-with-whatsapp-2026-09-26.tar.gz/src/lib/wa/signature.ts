import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Meta signs every webhook POST: `X-Hub-Signature-256: sha256=<hex HMAC-SHA256 of the raw body,
 * keyed with the app secret>`. Anything that doesn't verify is not from Meta.
 */
export function verifySignature(raw: Buffer | string, header: string | null, secret: string): boolean {
  if (!header || !secret) return false;
  const m = /^sha256=([0-9a-f]{64})$/i.exec(header.trim());
  if (!m) return false;
  const expected = createHmac("sha256", secret).update(raw).digest();
  const got = Buffer.from(m[1]!, "hex");
  return got.length === expected.length && timingSafeEqual(got, expected);
}

/** The header value Meta would send for this body (tests and the local e2e script). */
export const sign = (raw: Buffer | string, secret: string) =>
  "sha256=" + createHmac("sha256", secret).update(raw).digest("hex");
