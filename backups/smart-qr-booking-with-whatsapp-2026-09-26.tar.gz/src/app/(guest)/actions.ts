"use server";

/** Guest-side server actions: sign in with a WhatsApp code, book, send a UTR, cancel a hold. */
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requestCode, verifyCode } from "@/lib/guest-auth";
import { GUEST_COOKIE, GUEST_MAX_AGE, signGuestSession } from "@/lib/session";
import { currentGuest, safeNext } from "@/lib/guest";
import { cancelWebHold, claimFromWeb, createWebBooking } from "@/lib/web-booking";

export type SignInState = { n: number; step: "phone" | "code"; phone?: string; error?: string; devCode?: string };

export async function signInAction(prev: SignInState, fd: FormData): Promise<SignInState> {
  const next = safeNext(String(fd.get("next") ?? ""));
  const phone = String(fd.get("phone") ?? "");
  if (fd.get("step") === "code") {
    const r = await verifyCode(phone, String(fd.get("code") ?? ""));
    if (!r.ok) return { n: prev.n + 1, step: "code", phone, error: r.error };
    (await cookies()).set(GUEST_COOKIE, signGuestSession(r.customerId), {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: GUEST_MAX_AGE,
    });
    redirect(next);
  }
  const r = await requestCode(phone);
  if (!r.ok) return { n: prev.n + 1, step: fd.get("step") === "resend" ? "code" : "phone", phone, error: r.error };
  return { n: prev.n + 1, step: "code", phone: r.phone, ...(r.devCode ? { devCode: r.devCode } : {}) };
}

export async function signOutAction() {
  (await cookies()).delete(GUEST_COOKIE);
  redirect("/");
}

export type BookState = { n: number; error?: string };

export async function bookAction(prev: BookState, fd: FormData): Promise<BookState> {
  const guest = await currentGuest();
  const back = `/book?${new URLSearchParams({
    room: String(fd.get("roomId") ?? ""),
    from: String(fd.get("checkIn") ?? ""),
    to: String(fd.get("checkOut") ?? ""),
    guests: String(fd.get("guests") ?? ""),
  })}`;
  if (!guest) redirect(`/signin?next=${encodeURIComponent(back)}`);
  const r = await createWebBooking(guest.id, {
    roomId: String(fd.get("roomId") ?? ""),
    checkIn: String(fd.get("checkIn") ?? ""),
    checkOut: String(fd.get("checkOut") ?? ""),
    guests: Number(fd.get("guests") ?? 0),
    name: String(fd.get("name") ?? ""),
    contactPhone: String(fd.get("contactPhone") ?? ""),
  });
  if (!r.ok) {
    const error =
      r.code === "CONFLICT" ? "Sorry — those dates were just taken. Please pick other dates or another room." : r.message;
    return { n: prev.n + 1, error };
  }
  revalidatePath("/account");
  redirect(`/pay/${r.value.id}`);
}

export type ClaimState = { n: number; error?: string; sent?: string };

export async function claimAction(prev: ClaimState, fd: FormData): Promise<ClaimState> {
  const r = await claimFromWeb(String(fd.get("bookingId") ?? ""), String(fd.get("utr") ?? ""));
  if (!r.ok) return { n: prev.n + 1, error: r.message };
  revalidatePath(`/pay/${r.value.bookingId}`);
  return { n: prev.n + 1, sent: r.value.utr ?? "" };
}

export async function cancelHoldAction(fd: FormData) {
  const guest = await currentGuest();
  if (!guest) redirect("/signin?next=/account");
  await cancelWebHold(guest.id, String(fd.get("bookingId") ?? ""));
  revalidatePath("/account");
  redirect("/account");
}
