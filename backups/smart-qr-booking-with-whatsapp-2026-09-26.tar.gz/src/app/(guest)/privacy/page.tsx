import type { Metadata } from "next";
import { config } from "@/config";

export const metadata: Metadata = { title: "Privacy policy" };

const P = config.property;

const SECTIONS: { id?: string; title: string; body: string[] }[] = [
  {
    title: "What we collect",
    body: [
      "When you book or ask about a room — on this website or on WhatsApp — we keep your name, your WhatsApp number (and another contact number if you give one), the number of guests, your dates, and the messages you send us.",
      "When you pay, we keep the amount and the UPI reference (UTR) you give us so the front desk can match your payment. We never see or store your UPI PIN, card or bank details: you pay in your own UPI app.",
      "If you sign in on this website, we use a cookie to keep you signed in. We don't use advertising or tracking cookies.",
    ],
  },
  {
    title: "How we use it",
    body: [
      "To hold and confirm your booking, record what you've paid, send you confirmations and reminders (such as the day before check-out), answer your questions, and meet our legal and tax obligations as a hotel.",
      "We don't sell your information and don't use it for advertising.",
    ],
  },
  {
    title: "Who else handles it",
    body: [
      "WhatsApp (Meta Platforms) carries the messages between you and us. Our website and database are hosted by Vercel and Neon. They process your information only to provide those services to us.",
      "We share guest details with authorities only where the law requires it, for example guest registration rules for hotels in India.",
    ],
  },
  {
    title: "How long we keep it",
    body: [
      "Booking and payment records are kept for as long as the law requires us to keep accounts (normally up to 8 years). Chat details that aren't part of a booking are deleted after 12 months.",
    ],
  },
  {
    id: "delete",
    title: "Your choices — and deleting your data",
    body: [
      `You can ask to see, correct or delete the information we hold about you. Message us on WhatsApp at ${P.phone} or email ${P.email} with the phone number you used, and we'll reply within 30 days. We'll delete everything we aren't legally required to keep.`,
      "You can also stop our WhatsApp messages at any time by blocking our number or telling us in the chat.",
    ],
  },
  {
    title: "Security",
    body: [
      "Your information is stored in an access-controlled database; the owner's console is password-protected, and connections to this website are encrypted (HTTPS).",
    ],
  },
  {
    title: "Changes and contact",
    body: [
      `If we change this policy we'll update this page. Questions: ${P.name}, ${P.address} · ${P.phone} · ${P.email}.`,
    ],
  },
];

export default function PrivacyPage() {
  return (
    <div className="px-4 pt-28">
      <div className="mx-auto max-w-2xl">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-faint">{P.name}</p>
        <h1 className="font-display mt-2 text-4xl leading-tight text-ink">Privacy policy</h1>
        <p className="mt-3 text-[15px] leading-relaxed text-muted">
          How {P.name} uses the information you share when you book or message us. Last updated 26 September 2026.
        </p>
        <div className="mt-10 space-y-9">
          {SECTIONS.map((s) => (
            <section key={s.title} id={s.id} className="scroll-mt-28">
              <h2 className="font-display text-2xl text-ink">{s.title}</h2>
              {s.body.map((p) => (
                <p key={p.slice(0, 24)} className="mt-3 text-[15px] leading-relaxed text-muted">
                  {p}
                </p>
              ))}
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}
