import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { config } from "@/config";
import { currentGuest } from "@/lib/guest";
import { guestStays, type GuestStay } from "@/lib/web-booking";
import { bookingRef } from "@/lib/engine";
import { istDate, istTime } from "@/lib/dates";
import { formatDate, formatINR, formatTime, todayISO } from "@/lib/pricing";
import { waLink } from "@/lib/whatsapp";
import { cancelHoldAction, signOutAction } from "../actions";
import { StatusBadge } from "@/components/status-badge";
import { SubmitButton } from "@/components/admin/submit-button";
import { Icon } from "@/components/icons";

export const metadata: Metadata = { title: "My account", robots: { index: false, follow: false } };

const PAY_STATE: Record<string, string> = {
  AWAITING: "waiting for payment",
  CLAIMED: "being checked by the front desk",
  ACKNOWLEDGED: "received",
  REJECTED: "not found yet — please check the UTR",
  CANCELLED: "cancelled",
};
const KIND: Record<string, string> = { ADVANCE: "Advance", EXTENSION: "Extension", BALANCE: "Balance" };

function StayCard({ s }: { s: GuestStay }) {
  const ref = bookingRef(s.root);
  const end = s.parts.filter((p) => p.status !== "CANCELLED").at(-1) ?? s.root;
  const upcoming = istDate(end.checkOutAt) >= todayISO();
  const moved = s.parts.some((p, i) => i > 0 && p.roomId !== s.parts[i - 1]!.roomId);
  const statusLabel =
    s.status === "PENDING" ? "Awaiting payment" : s.status === "CONFIRMED" ? (upcoming ? "Confirmed" : "Completed") : "Cancelled";

  return (
    <li className="rounded-[1.5rem] border border-hairline bg-paper p-1.5">
      <div className="rounded-[1.15rem] bg-sand/30 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="font-display text-xl text-ink">
              Room {s.parts.filter((p) => p.status !== "CANCELLED").map((p) => p.roomId).filter((r, i, a) => a.indexOf(r) === i).join(" → ")}
            </p>
            <p className="text-[13px] text-muted">
              {s.root.room.name}
              {moved && " · room change during the stay"}
            </p>
          </div>
          <StatusBadge status={s.status.toLowerCase()} label={statusLabel} />
        </div>

        <p className="mt-3 text-[14px] text-ink">
          {formatDate(istDate(s.root.checkInAt))}, {formatTime(istTime(s.root.checkInAt))} → {formatDate(istDate(end.checkOutAt))},{" "}
          {formatTime(istTime(end.checkOutAt))}
        </p>
        <p className="text-[12px] text-faint">
          Ref {ref} · {s.root.guests} guest{s.root.guests === 1 ? "" : "s"}
          {s.parts.length > 1 && ` · extended ${s.parts.length - 1}×`}
        </p>

        {s.status !== "CANCELLED" && (
          <dl className="mt-4 grid grid-cols-3 gap-2 text-[13px]">
            <div>
              <dt className="text-[11px] uppercase tracking-[0.12em] text-faint">Total</dt>
              <dd className="text-ink">{formatINR(s.total)}</dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-[0.12em] text-faint">Paid</dt>
              <dd className="text-sage">{formatINR(s.paid)}</dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-[0.12em] text-faint">Due</dt>
              <dd className="font-medium text-ink">{formatINR(s.total - s.paid)}</dd>
            </div>
          </dl>
        )}

        {s.payments.length > 0 && (
          <ul className="mt-3 space-y-1 border-t border-hairline pt-3 text-[12.5px] text-muted">
            {s.payments.map((p) => (
              <li key={p.id} className="flex justify-between gap-3">
                <span>
                  {KIND[p.kind]} · {formatINR(p.amount)}
                  {p.utr && <span className="text-faint"> · UTR {p.utr}</span>}
                </span>
                <span className={p.status === "ACKNOWLEDGED" ? "text-sage" : p.status === "REJECTED" ? "text-clay" : ""}>
                  {PAY_STATE[p.status]}
                </span>
              </li>
            ))}
          </ul>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          {s.awaiting && (
            <Link
              href={`/pay/${s.awaiting.id}`}
              className="rounded-full bg-ink px-4 py-2 text-[13px] font-medium text-cream"
            >
              Pay {s.awaiting.parentId ? "for the extension" : "the advance"}
            </Link>
          )}
          {s.status === "PENDING" && (
            <form action={cancelHoldAction}>
              <input type="hidden" name="bookingId" value={s.root.id} />
              <SubmitButton
                confirm={`Cancel ${ref}? The room is released.`}
                pendingText="Cancelling…"
                className="rounded-full border border-hairline px-4 py-2 text-[13px] text-muted hover:text-clay"
              >
                Cancel booking
              </SubmitButton>
            </form>
          )}
          {s.status === "CONFIRMED" && upcoming && (
            <a
              href={waLink(`Hi! I'd like to extend my stay (${ref}).`)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full bg-[#1f8a4c] px-4 py-2 text-[13px] font-medium text-white"
            >
              <Icon.whatsapp width={14} height={14} />
              Extend on WhatsApp
            </a>
          )}
        </div>
      </div>
    </li>
  );
}

export default async function AccountPage() {
  const guest = await currentGuest();
  if (!guest) redirect("/signin?next=/account");
  const stays = await guestStays(guest.id);
  const today = todayISO();
  const endOf = (s: GuestStay) => istDate((s.parts.filter((p) => p.status !== "CANCELLED").at(-1) ?? s.root).checkOutAt);
  const current = stays.filter((s) => s.status !== "CANCELLED" && endOf(s) >= today);
  const past = stays.filter((s) => !(s.status !== "CANCELLED" && endOf(s) >= today));

  return (
    <div className="px-4 pt-28">
      <div className="mx-auto max-w-2xl">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-faint">{config.property.name}</p>
            <h1 className="font-display mt-2 text-3xl text-ink">{guest.name ? `Hi, ${guest.name.split(" ")[0]}` : "Your account"}</h1>
            <p className="mt-1 text-[13px] text-muted">+{guest.phone}</p>
          </div>
          <div className="flex gap-2">
            <Link href="/rooms" className="rounded-full bg-clay px-4 py-2 text-[13px] font-medium text-white">
              Book a room
            </Link>
            <form action={signOutAction}>
              <button type="submit" className="rounded-full border border-hairline px-4 py-2 text-[13px] text-muted hover:text-ink">
                Sign out
              </button>
            </form>
          </div>
        </div>

        <h2 className="mt-10 text-[11px] font-semibold uppercase tracking-[0.18em] text-faint">Upcoming &amp; current</h2>
        {current.length === 0 ? (
          <p className="mt-3 rounded-2xl border border-hairline bg-paper px-4 py-6 text-center text-[14px] text-muted">
            No upcoming stays. <Link href="/rooms" className="text-clay">Find a room →</Link>
          </p>
        ) : (
          <ul className="mt-3 space-y-3">
            {current.map((s) => (
              <StayCard key={s.root.id} s={s} />
            ))}
          </ul>
        )}

        {past.length > 0 && (
          <>
            <h2 className="mt-10 text-[11px] font-semibold uppercase tracking-[0.18em] text-faint">Past &amp; cancelled</h2>
            <ul className="mt-3 space-y-3 opacity-80">
              {past.map((s) => (
                <StayCard key={s.root.id} s={s} />
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  );
}
