import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { config } from "@/config";
import { currentGuest, safeNext } from "@/lib/guest";
import { signInAvailable } from "@/lib/guest-auth";
import { enquiryMessage, waLink } from "@/lib/whatsapp";
import { SignInForm } from "@/components/signin-form";
import { Icon } from "@/components/icons";

export const metadata: Metadata = { title: "Sign in", robots: { index: false, follow: false } };

export default async function SignInPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next: raw } = await searchParams;
  const next = safeNext(raw);
  if (await currentGuest()) redirect(next);
  // Without the WhatsApp code template (waiting for Meta's approval) codes can't be sent: say so
  // before the guest types their number, and send them to WhatsApp, where booking always works.
  const available = signInAvailable();
  return (
    <div className="px-4 pt-28">
      <div className="mx-auto max-w-sm">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-faint">{config.property.name}</p>
        <h1 className="font-display mt-2 text-3xl leading-tight text-ink">Sign in</h1>
        <p className="mt-2 text-[14px] leading-relaxed text-muted">
          {available
            ? "See your bookings, pay, and book online. We'll send a code to your WhatsApp."
            : "Online sign-in isn't open yet. Book on WhatsApp instead — it takes a minute, and you'll pay and get your confirmation right in the chat."}
        </p>
        <div className="mt-6 rounded-[1.5rem] border border-hairline bg-paper p-1.5">
          <div className="rounded-[1.15rem] bg-sand/40 p-5">
            {available ? (
              <SignInForm next={next} />
            ) : (
              <a
                href={waLink(enquiryMessage({}))}
                target="_blank"
                rel="noopener noreferrer"
                className="flex w-full items-center justify-center gap-2 rounded-full bg-[#1f8a4c] py-2.5 text-[14px] font-medium text-white"
              >
                <Icon.whatsapp width={16} height={16} />
                Book on WhatsApp
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
