import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound, redirect } from "next/navigation";
import { config } from "@/config";
import { currentGuest } from "@/lib/guest";
import { getRooms } from "@/lib/rooms";
import { isFree, bookingRef } from "@/lib/engine";
import { pendingHoldFor } from "@/lib/web-booking";
import { toInstant } from "@/lib/dates";
import { formatDate, formatINR, nights as nightsBetween, todayISO } from "@/lib/pricing";
import { BookForm } from "@/components/book-form";
import { Icon } from "@/components/icons";

export const metadata: Metadata = { title: "Book", robots: { index: false, follow: false } };

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

export default async function BookPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const roomId = one(sp.room);
  const from = one(sp.from);
  const to = one(sp.to);
  const guestsWanted = Number(one(sp.guests)) || 2;
  const self = `/book?${new URLSearchParams({ room: roomId, from, to, guests: String(guestsWanted) })}`;

  const guest = await currentGuest();
  if (!guest) redirect(`/signin?next=${encodeURIComponent(self)}`);

  const room = (await getRooms()).find((r) => r.id === roomId);
  if (!room) notFound();
  const back = `/rooms/${room.id}`;

  const n = DATE_RE.test(from) && DATE_RE.test(to) ? nightsBetween(from, to) : 0;
  const problem =
    n < 1
      ? "Pick your check-in and check-out dates first."
      : n > config.defaults.maxNights
        ? `Stays are up to ${config.defaults.maxNights} nights.`
        : from < todayISO()
          ? "Check-in can't be in the past."
          : !(await isFree(room.id, toInstant(from, config.defaults.checkInTime), toInstant(to, config.defaults.checkOutTime)))
            ? `Room ${room.id} is booked on some of those nights.`
            : null;
  const held = await pendingHoldFor(guest.phone);
  const total = room.pricePerNight * Math.max(n, 0);
  const advance = Math.round(total * config.advanceRate);

  return (
    <div className="px-4 pt-28">
      <div className="mx-auto max-w-2xl">
        <Link href={back} className="inline-flex items-center gap-1.5 text-[13px] text-muted hover:text-ink">
          <Icon.arrowLeft width={14} height={14} /> Room {room.id}
        </Link>
        <h1 className="font-display mt-3 text-3xl text-ink">Book Room {room.id}</h1>

        <div className="mt-6 grid gap-5 sm:grid-cols-[200px_1fr]">
          <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-hairline bg-sand">
            {room.images[0] && <Image src={room.images[0]} alt={room.name} fill sizes="200px" className="object-cover" />}
          </div>
          <div className="text-[14px] text-muted">
            <p className="font-display text-xl text-ink">{room.name}</p>
            {n > 0 && (
              <>
                <p className="mt-1">
                  {formatDate(from)} → {formatDate(to)} · {n} night{n === 1 ? "" : "s"}
                </p>
                <p className="mt-2 text-ink">
                  Total <strong>{formatINR(total)}</strong> · pay {formatINR(advance)} now ({Math.round(config.advanceRate * 100)}%),
                  rest at check-in
                </p>
              </>
            )}
          </div>
        </div>

        <div className="mt-6 rounded-[1.5rem] border border-hairline bg-paper p-1.5">
          <div className="rounded-[1.15rem] bg-sand/30 p-5">
            {held ? (
              <div className="space-y-3 text-[14px] text-ink">
                <p>
                  You already have Room {held.roomId} on hold ({bookingRef(held)}). Pay for it or cancel it before booking another
                  room.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Link href={`/pay/${held.id}`} className="rounded-full bg-ink px-4 py-2 text-[13px] font-medium text-cream">
                    Pay for {bookingRef(held)}
                  </Link>
                  <Link href="/account" className="rounded-full border border-hairline px-4 py-2 text-[13px] text-muted">
                    My account
                  </Link>
                </div>
              </div>
            ) : problem ? (
              <div className="space-y-3 text-[14px] text-ink">
                <p>{problem}</p>
                <Link href={back} className="inline-flex rounded-full bg-ink px-4 py-2 text-[13px] font-medium text-cream">
                  Choose dates
                </Link>
              </div>
            ) : (
              <BookForm
                roomId={room.id}
                checkIn={from}
                checkOut={to}
                guests={Math.min(Math.max(guestsWanted, 1), room.capacity)}
                capacity={room.capacity}
                name={guest.name}
                phone={guest.phone}
                advance={formatINR(advance)}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
