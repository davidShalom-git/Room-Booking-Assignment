import { SiteNav } from "@/components/site-nav";
import { currentGuest } from "@/lib/guest";
import { Footer } from "@/components/footer";
import { ChatWidget } from "@/components/chat-widget";
import { config } from "@/config";

export default async function GuestLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const guest = await currentGuest();
  return (
    <div className="flex min-h-[100dvh] flex-col">
      <SiteNav signedIn={!!guest} />
      <main className="flex-1">{children}</main>
      <Footer />
      <ChatWidget name={config.property.name} />
    </div>
  );
}
