/**
 * WhatsApp Cloud API webhook.
 *   GET  — Meta's one-time verification handshake (hub.verify_token must match WA_VERIFY_TOKEN).
 *   POST — incoming messages. Signature checked against WA_APP_SECRET before anything else.
 * Messages are processed before answering, so a failure returns 500 and Meta re-delivers.
 */
import { env } from "@/lib/env";
import { verifySignature } from "@/lib/wa/signature";
import { parseInbound } from "@/lib/wa/inbound";
import { handleInbound } from "@/lib/wa/handle";

export const maxDuration = 30;

export async function GET(request: Request) {
  const q = new URL(request.url).searchParams;
  let expected = "";
  try {
    expected = env.waVerifyToken;
  } catch {
    console.error("[wa] WA_VERIFY_TOKEN is not set");
  }
  const challenge = q.get("hub.challenge");
  if (q.get("hub.mode") === "subscribe" && expected && q.get("hub.verify_token") === expected && challenge) {
    return new Response(challenge, { status: 200, headers: { "content-type": "text/plain" } });
  }
  return new Response("Forbidden", { status: 403 });
}

export async function POST(request: Request) {
  let secret: string;
  try {
    secret = env.waAppSecret;
  } catch {
    console.error("[wa] WA_APP_SECRET is not set");
    return new Response("Not configured", { status: 500 });
  }
  const raw = Buffer.from(await request.arrayBuffer());
  if (!verifySignature(raw, request.headers.get("x-hub-signature-256"), secret)) {
    return new Response("Invalid signature", { status: 401 });
  }
  let body: unknown;
  try {
    body = JSON.parse(raw.toString("utf8"));
  } catch {
    return new Response("Bad JSON", { status: 400 });
  }
  const ok = await handleInbound(parseInbound(body));
  return new Response(ok ? "OK" : "Retry", { status: ok ? 200 : 500 });
}
