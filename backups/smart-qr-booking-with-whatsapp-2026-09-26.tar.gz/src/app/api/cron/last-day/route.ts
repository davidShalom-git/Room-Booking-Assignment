/**
 * Daily at 17:00 IST (vercel.json): ask guests who check out tomorrow whether they'd like to
 * extend. Vercel Cron calls this with `Authorization: Bearer $CRON_SECRET`.
 */
import { prisma } from "@/lib/db";
import { cronAuthorized } from "@/lib/secure";
import { lastDayNudges } from "@/lib/bot/step";
import { prismaPorts } from "@/lib/bot/ports-prisma";
import { deliver } from "@/lib/wa/deliver";
import { addDays, todayISO } from "@/lib/pricing";

export const maxDuration = 60;

export async function GET(request: Request) {
  if (!cronAuthorized(request)) return new Response("Unauthorized", { status: 401 });

  const now = new Date();
  const tomorrow = addDays(todayISO(now), 1);
  // Each nudge is claimed on its booking before it is sent, so a rerun never repeats one.
  const nudges = await lastDayNudges(prismaPorts(), tomorrow);
  await deliver(nudges, now);
  // Webhook dedupe markers only need to outlive Meta's retry window.
  await prisma.processedMessage.deleteMany({ where: { createdAt: { lt: new Date(now.getTime() - 7 * 86_400_000) } } });
  return Response.json({ sent: nudges.length, for: tomorrow });
}
