"use client";

import { useActionState } from "react";
import { bookAction, type BookState } from "@/app/(guest)/actions";
import { SubmitButton } from "@/components/admin/submit-button";

const input =
  "mt-1.5 w-full rounded-xl border border-hairline bg-paper px-3.5 py-2.5 text-[15px] text-ink outline-none transition-colors focus:border-clay";

export function BookForm(p: {
  roomId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  capacity: number;
  name: string;
  phone: string;
  advance: string;
}) {
  const [state, action] = useActionState<BookState, FormData>(bookAction, { n: 0 });
  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="roomId" value={p.roomId} />
      <input type="hidden" name="checkIn" value={p.checkIn} />
      <input type="hidden" name="checkOut" value={p.checkOut} />
      <label className="block">
        <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-faint">Name for the booking</span>
        <input name="name" defaultValue={p.name} required minLength={2} maxLength={80} autoComplete="name" className={input} />
      </label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-faint">Guests</span>
          <select name="guests" defaultValue={p.guests} className={input}>
            {Array.from({ length: p.capacity }, (_, i) => i + 1).map((n) => (
              <option key={n} value={n}>
                {n} guest{n === 1 ? "" : "s"}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-faint">Contact number (optional)</span>
          <input name="contactPhone" type="tel" placeholder={`+${p.phone}`} className={input} />
        </label>
      </div>
      {state.error && (
        <p role="alert" className="rounded-2xl border border-clay/30 bg-clay-soft px-4 py-3 text-[13px] text-clay-dark">
          {state.error}
        </p>
      )}
      <SubmitButton pendingText="Holding your room…" className="w-full rounded-full bg-clay py-3 text-[15px] font-medium text-white">
        Hold the room &amp; pay {p.advance}
      </SubmitButton>
      <p className="text-center text-[12px] text-faint">
        The room is held for you while you pay the advance by UPI. The front desk confirms on WhatsApp.
      </p>
    </form>
  );
}
