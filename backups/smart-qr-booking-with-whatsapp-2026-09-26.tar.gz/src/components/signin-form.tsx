"use client";

import { useActionState } from "react";
import { signInAction, type SignInState } from "@/app/(guest)/actions";
import { SubmitButton } from "@/components/admin/submit-button";
import { Icon } from "@/components/icons";

const input =
  "mt-1.5 w-full rounded-xl border border-hairline bg-paper px-3.5 py-3 text-[16px] text-ink outline-none transition-colors focus:border-clay";

/** Two steps: WhatsApp number → 6-digit code sent on WhatsApp. */
export function SignInForm({ next }: { next: string }) {
  const [state, action] = useActionState<SignInState, FormData>(signInAction, { n: 0, step: "phone" });

  if (state.step === "code") {
    return (
      <div>
        <form key={`code-${state.n}`} action={action} className="space-y-4">
          <input type="hidden" name="step" value="code" />
          <input type="hidden" name="phone" value={state.phone} />
          <input type="hidden" name="next" value={next} />
          <p className="flex items-start gap-2 rounded-2xl bg-sage-soft px-4 py-3 text-[13px] text-sage">
            <Icon.whatsapp width={16} height={16} className="mt-0.5 shrink-0" />
            We've sent a 6-digit code to +{state.phone} on WhatsApp.
          </p>
          {state.devCode && (
            <p className="rounded-2xl border border-dashed border-hairline px-4 py-2 text-[12px] text-muted">
              Development mode (no WhatsApp template set): your code is <strong>{state.devCode}</strong>
            </p>
          )}
          <label className="block">
            <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-faint">Code</span>
            <input
              name="code"
              inputMode="numeric"
              autoComplete="one-time-code"
              pattern="[0-9 ]*"
              maxLength={7}
              required
              autoFocus
              className={`${input} tracking-[0.4em]`}
            />
          </label>
          {state.error && (
            <p role="alert" className="text-[13px] text-clay">
              {state.error}
            </p>
          )}
          <SubmitButton pendingText="Checking…" className="w-full rounded-full bg-ink py-3 text-[15px] font-medium text-cream">
            Sign in
          </SubmitButton>
        </form>
        <form action={action} className="mt-3 text-center">
          <input type="hidden" name="step" value="resend" />
          <input type="hidden" name="phone" value={state.phone} />
          <input type="hidden" name="next" value={next} />
          <button type="submit" className="text-[13px] text-muted underline-offset-2 hover:text-ink hover:underline">
            Didn't get it? Send a new code
          </button>
        </form>
      </div>
    );
  }

  return (
    <form key={`phone-${state.n}`} action={action} className="space-y-4">
      <input type="hidden" name="step" value="phone" />
      <input type="hidden" name="next" value={next} />
      <label className="block">
        <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-faint">Your WhatsApp number</span>
        <input
          name="phone"
          type="tel"
          inputMode="tel"
          autoComplete="tel"
          placeholder="+91 98450 21133"
          defaultValue={state.phone}
          required
          autoFocus
          className={input}
        />
      </label>
      {state.error && (
        <p role="alert" className="text-[13px] text-clay">
          {state.error}
        </p>
      )}
      <SubmitButton pendingText="Sending…" className="w-full rounded-full bg-ink py-3 text-[15px] font-medium text-cream">
        Send me a code on WhatsApp
      </SubmitButton>
      <p className="text-center text-[12px] text-faint">No password needed. First time? Your account is created automatically.</p>
    </form>
  );
}
