/**
 * End-to-end check of the production build, with WhatsApp simulated at the HTTP boundary.
 *
 *   npm run build && npm run e2e
 *
 * Starts `next start` against a scratch database (E2E_DATABASE_URL, default coral_e2e on the
 * local Docker Postgres), points the app at a mock Graph API, then drives real journeys by
 * POSTing signed webhook payloads exactly as Meta would. Asserts on the database and on every
 * message the app tries to send.
 */
import "dotenv/config";
import assert from "node:assert/strict";
import { execSync, spawn } from "node:child_process";
import { startMockGraph, metaPayload, textMsg, buttonMsg } from "../tests/helpers/mockGraph";
import { sign } from "../src/lib/wa/signature";
import { addDays, formatDate, todayISO } from "../src/lib/pricing";
import { signOwnerAction } from "../src/lib/session";

const DB = process.env["E2E_DATABASE_URL"] ?? "postgresql://coral:coral@localhost:55432/coral_e2e";
const PORT = 3210;
const BASE = `http://localhost:${PORT}`;
const SECRET = "e2e-app-secret";
const GUEST = "919812345678";
const GUEST2 = "919700000002";
const OWNER = "919000000001";
const SESSION = "e2e-session-secret-e2e-session-secret";

let seq = 0;
const step = (s: string) => console.log(`ok  - ${s}`);

async function main() {
  // Fresh scratch database.
  const admin = DB.replace(/\/[^/?]+(\?.*)?$/, "/postgres");
  const name = /\/([^/?]+)(\?|$)/.exec(DB)![1];
  execSync(`docker compose exec -T db psql -U coral -d postgres -c "DROP DATABASE IF EXISTS ${name} WITH (FORCE)" -c "CREATE DATABASE ${name}"`, { stdio: "ignore" });
  void admin;
  const dbEnv = { ...process.env, DATABASE_URL: DB };
  execSync("npx prisma migrate deploy", { env: dbEnv, stdio: "ignore" });
  execSync("npx tsx prisma/seed.ts", { env: dbEnv, stdio: "ignore" });
  process.env["DATABASE_URL"] = DB;
  const { prisma } = await import("../src/lib/db");
  step("scratch database migrated and seeded");

  const mock = await startMockGraph();
  const server = spawn(process.execPath, [require.resolve("next/dist/bin/next"), "start", "-p", String(PORT)], {
    env: {
      ...process.env,
      DATABASE_URL: DB,
      WA_API_BASE: mock.base,
      WA_ACCESS_TOKEN: "e2e-token",
      WA_PHONE_NUMBER_ID: "PNID",
      WA_APP_SECRET: SECRET,
      WA_VERIFY_TOKEN: "e2e-verify",
      WA_TPL_NOTIFY: "",
      WA_TPL_LAST_DAY: "",
      WA_TPL_OTP: "",
      OWNER_WHATSAPP: OWNER,
      UPI_ID: "coral@upi",
      CRON_SECRET: "e2e-cron",
      ADMIN_PASSWORD: "e2e-password",
      SESSION_SECRET: SESSION,
    },
    stdio: ["ignore", "ignore", "inherit"],
  });

  try {
    for (let i = 0; ; i++) {
      try {
        const r = await fetch(`${BASE}/api/health`);
        if (r.ok && (await r.json()).ok) break;
      } catch {}
      if (i > 60) throw new Error("server did not start");
      await new Promise((r) => setTimeout(r, 500));
    }
    step("production server up, /api/health ok");

    const post = async (messages: Record<string, unknown>[], secret = SECRET) => {
      const body = JSON.stringify(metaPayload(messages));
      return fetch(`${BASE}/api/whatsapp`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-hub-signature-256": sign(body, secret) },
        body,
      });
    };
    const say = async (from: string, text: string) => assert.equal((await post([textMsg(`wamid.e2e.${++seq}`, from, text)])).status, 200);
    const tap = async (from: string, id: string) => assert.equal((await post([buttonMsg(`wamid.e2e.${++seq}`, from, id)])).status, 200);
    const last = (to: string) => mock.sentTo(to).at(-1);
    const bodyText = (m: any) => m?.text?.body ?? m?.interactive?.body?.text ?? ""; // eslint-disable-line @typescript-eslint/no-explicit-any
    const ids = (m: any): string[] => // eslint-disable-line @typescript-eslint/no-explicit-any
      m?.interactive?.action?.buttons?.map((b: any) => b.reply.id) ?? // eslint-disable-line @typescript-eslint/no-explicit-any
      m?.interactive?.action?.sections?.[0]?.rows?.map((r: any) => r.id) ?? []; // eslint-disable-line @typescript-eslint/no-explicit-any

    // --- webhook plumbing
    const hs = await fetch(`${BASE}/api/whatsapp?hub.mode=subscribe&hub.verify_token=e2e-verify&hub.challenge=424242`);
    assert.equal(await hs.text(), "424242");
    assert.equal((await post([textMsg("wamid.bad", GUEST, "hi")], "wrong-secret")).status, 401);
    step("webhook verification handshake + signature rejection");

    // --- guest books room 101 from the QR code
    const checkIn = addDays(todayISO(), 10);
    await say(GUEST, `Hi! I'm interested in *Room 101 — Deluxe Double Room* at The Coral Courtyard.\nCould you tell me about availability?\n${BASE}/rooms/101`);
    assert.deepEqual(ids(last(GUEST)), ["info", "avail", "book"]);
    await tap(GUEST, "book");
    await say(GUEST, "Asha Nair");
    await tap(GUEST, "contact_wa");
    await tap(GUEST, "g:2");
    await say(GUEST, formatDate(checkIn));
    await say(GUEST, formatDate(addDays(checkIn, 2)));
    assert.match(bodyText(last(GUEST)), /₹3,600/);
    await tap(GUEST, "confirm");
    const held = await prisma.booking.findFirstOrThrow({ where: { guestPhone: GUEST } });
    assert.equal(held.status, "PENDING");
    const payMsg = last(GUEST);
    assert.ok(bodyText(payMsg).includes(`/pay/${held.id}`), "chat links to the pay page");
    assert.deepEqual(ids(payMsg), [`i_paid:${held.id}`, `cancel_hold:${held.id}`]);
    const payPage = await (await fetch(`${BASE}/pay/${held.id}`)).text();
    assert.ok(payPage.includes("upi://pay?pa=coral@upi&amp;pn=The%20Coral%20Courtyard&amp;am=1800.00"), "UPI deep link");
    assert.ok(payPage.includes("<svg"), "UPI QR code");
    step("guest: QR -> questions -> name, contact, guests, dates -> hold; pay page with UPI link + QR");

    // --- a double tap on Confirm (both copies at once) must not break anything
    await Promise.all([tap(GUEST, "confirm"), tap(GUEST, "confirm")]);
    assert.equal(await prisma.booking.count({ where: { guestPhone: GUEST, status: "PENDING" } }), 1);
    assert.ok(!mock.sentTo(GUEST).some((m) => /just taken/i.test(bodyText(m))));
    step("double tap on Confirm: still exactly one hold, no false 'just taken'");

    // --- the guest sends the UTR; the owner hasn't written in, so the alert waits for them
    await tap(GUEST, `i_paid:${held.id}`);
    await say(GUEST, "412345678901");
    assert.match(bodyText(last(GUEST)), /with the front desk/);
    assert.equal(mock.sentTo(OWNER).length, 0);
    await say(OWNER, "hi");
    const alert = mock.sentTo(OWNER)[0];
    assert.match(bodyText(alert), /Asha Nair/);
    assert.match(bodyText(alert), /UTR: \*412345678901\*/);
    const ack = ids(alert).find((x) => x.startsWith("ack:"));
    assert.ok(ack && ids(alert).some((x) => x.startsWith("nack:")));
    step("guest sends the UTR -> owner's alert (who / room / amount / UTR) arrives the moment they write in");

    await tap(OWNER, ack!);
    const confirmed = await prisma.booking.findUniqueOrThrow({ where: { id: held.id } });
    assert.equal(confirmed.status, "CONFIRMED");
    assert.equal(confirmed.advancePaid, 1800);
    assert.match(bodyText(last(GUEST)), /Booking confirmed/);
    assert.ok((await (await fetch(`${BASE}/pay/${held.id}`)).text()).includes("Booking confirmed"));
    step("owner acknowledges -> confirmed, ₹1,800 recorded, guest told, pay page shows it");

    // --- same dates for another guest: offered other rooms
    await say(GUEST2, `Hi! I'm interested in *Room 101 — Deluxe Double Room*.\n${BASE}/rooms/101`);
    await tap(GUEST2, "book");
    await say(GUEST2, "Ravi Menon");
    await tap(GUEST2, "contact_wa");
    await say(GUEST2, "2");
    await say(GUEST2, formatDate(checkIn));
    await say(GUEST2, "2");
    assert.ok(ids(last(GUEST2)).includes("pick:102"), "alternatives offered");
    step("second guest, same dates: room 101 is taken, free rooms offered");

    // --- a stay that ends tomorrow: booked, paid, acknowledged, then nudged by the cron
    await tap(GUEST2, "change");
    await tap(GUEST2, "d:today");
    await tap(GUEST2, "n:1");
    await tap(GUEST2, "confirm");
    const stay2 = await prisma.booking.findFirstOrThrow({ where: { guestPhone: GUEST2, status: "PENDING" } });
    await tap(GUEST2, `i_paid:${stay2.id}`);
    await say(GUEST2, "555566667777");
    await tap(OWNER, ids(last(OWNER)).find((x) => x.startsWith("ack:"))!);
    assert.equal((await prisma.booking.findUniqueOrThrow({ where: { id: stay2.id } })).status, "CONFIRMED");
    const cron = await fetch(`${BASE}/api/cron/last-day`, { headers: { authorization: "Bearer e2e-cron" } });
    assert.equal((await cron.json()).sent, 1);
    assert.deepEqual(ids(last(GUEST2)), [`want_extend:${stay2.id}`, `want_out:${stay2.id}`]);
    assert.equal((await fetch(`${BASE}/api/cron/last-day`)).status, 401);
    step("cron: last-day nudge sent once (and refused without the secret)");

    // --- extension: same room free -> held, paid in full, acknowledged
    await tap(GUEST2, `want_extend:${stay2.id}`);
    await say(GUEST2, "+2 nights");
    const seg = await prisma.booking.findFirstOrThrow({ where: { parentId: stay2.id, status: "PENDING" } });
    assert.match(bodyText(last(GUEST2)), /is free until/);
    await tap(GUEST2, `i_paid:${seg.id}`);
    await say(GUEST2, "999988887777");
    assert.match(bodyText(last(OWNER)), /extends Room/);
    await tap(OWNER, ids(last(OWNER)).find((x) => x.startsWith("ack:"))!);
    assert.equal((await prisma.booking.findUniqueOrThrow({ where: { id: seg.id } })).status, "CONFIRMED");
    assert.match(bodyText(last(GUEST2)), /You're extended/);
    step("extension: guest asks, pays the extra nights in full, owner acknowledges, guest told");

    // --- the website chat (no Meta): book in the chat; the owner acknowledges from the app's notification
    type ChatMsg = { fromGuest: boolean; text: string };
    let chatCookie = "";
    const chat = async (body: Record<string, unknown>): Promise<ChatMsg[]> => {
      const r = await fetch(`${BASE}/api/chat`, {
        method: "POST",
        headers: { "content-type": "application/json", ...(chatCookie ? { cookie: chatCookie } : {}) },
        body: JSON.stringify(body),
      });
      const set = r.headers.get("set-cookie");
      if (set) chatCookie = set.split(";")[0]!;
      const j = (await r.json()) as { ok: boolean; error?: string; messages: ChatMsg[] };
      assert.ok(j.ok, j.error);
      return j.messages;
    };
    const webIn = addDays(todayISO(), 20);
    await chat({ text: "Hi, I'm interested in Room 102." });
    await chat({ button: "book", title: "Book this room" });
    await chat({ text: "Meera Pillai" });
    await chat({ text: "98470 11111" });
    await chat({ text: "2" });
    await chat({ text: formatDate(webIn) });
    await chat({ text: "2" });
    await chat({ button: "confirm", title: "Confirm booking" });
    const webHold = await prisma.booking.findFirstOrThrow({ where: { guestName: "Meera Pillai", status: "PENDING" } });
    assert.ok(webHold.chatKey?.startsWith("web:") && webHold.source === "WEB" && webHold.guestPhone === "919847011111");
    await chat({ button: `i_paid:${webHold.id}`, title: "I've paid" });
    await chat({ text: "321098765432" });
    const webPay = await prisma.payment.findFirstOrThrow({ where: { bookingId: webHold.id } });
    assert.equal(webPay.status, "CLAIMED");
    process.env["SESSION_SECRET"] = SESSION;
    const act = (await (
      await fetch(`${BASE}/api/owner/act`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "ack", token: signOwnerAction(webPay.id) }),
      })
    ).json()) as { ok: boolean; whatsapp?: string };
    assert.ok(act.ok && act.whatsapp?.startsWith("https://wa.me/919847011111?text="), "offers the WhatsApp confirmation");
    const later = (await (await fetch(`${BASE}/api/chat?after=0`, { headers: { cookie: chatCookie } })).json()) as { messages: ChatMsg[] };
    assert.match(later.messages.at(-1)!.text, /Booking confirmed/);
    const forged = await fetch(`${BASE}/api/owner/act`, { method: "POST", body: JSON.stringify({ action: "ack", token: "x.1.y" }) });
    assert.equal(forged.status, 400);
    step("website chat: book + UTR in the chat; owner acknowledges from the notification; confirmation appears in the chat");

    // --- availability API + guest pages + admin guard
    const av = await (await fetch(`${BASE}/api/availability?room=101&from=${checkIn}&to=${addDays(checkIn, 1)}`)).json();
    assert.equal(av.available, false);
    for (const path of ["/", "/rooms", "/rooms/101", "/qr", "/about", "/contact", "/signin", "/privacy", "/owner.webmanifest", "/owner-icon/192", "/owner-sw.js"]) {
      const r = await fetch(BASE + path);
      assert.equal(r.status, 200, path);
    }
    assert.equal((await fetch(`${BASE}/rooms/nope`)).status, 404);
    const guard = await fetch(`${BASE}/admin/bookings`, { redirect: "manual" });
    assert.ok([302, 307].includes(guard.status) && guard.headers.get("location")?.includes("/admin/login"));
    for (const path of ["/account", `/book?room=101&from=${checkIn}&to=${addDays(checkIn, 1)}`]) {
      const r = await fetch(BASE + path, { redirect: "manual" });
      assert.ok([302, 303, 307].includes(r.status) || (await r.text()).includes("NEXT_REDIRECT"), path);
    }
    step("availability API, guest pages render, /admin and /account require sign-in");

    // --- no sign-in code template yet (waiting for Meta): the sign-in page points to WhatsApp up front
    const signin = await (await fetch(`${BASE}/signin`)).text();
    assert.ok(signin.includes("Book on WhatsApp") && !signin.includes('name="phone"'), "WhatsApp instead of the code form");
    step("without WA_TPL_OTP, /signin offers booking on WhatsApp instead of a code form that can't send");

    console.log(`\nE2E passed — ${mock.requests.length} WhatsApp messages sent, ${await prisma.booking.count()} bookings.`);
    await prisma.$disconnect();
  } finally {
    server.kill();
    await mock.stop();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
