# The Coral Courtyard — WhatsApp-first hotel booking

A booking system for a small hotel with two front doors: WhatsApp and the website. One database behind both.

> **Room QR / website → WhatsApp chat or online booking → guest pays a 50% advance by UPI and sends the UTR → owner acknowledges → booked. Extensions: self-service, paid in full, acknowledged the same way.**

- **Guests** scan a room's QR code (or tap any WhatsApp button on the website). The WhatsApp assistant answers questions and checks the real calendar. It takes the booking (name, guests, dates) and holds the room for 2 hours while they pay the 50% advance. Payment is a link to a pay page: one tap opens their UPI app with the amount filled in, or they can scan the QR code there. Guests can also type *my booking* at any time to see their booking status. The evening before check-out, it asks whether they'd like to extend or check out as planned.
- **Booking on WhatsApp:** name (remembered for returning guests), contact number, guests, check-in and check-out → the room is held → a pay link opens their UPI app → they tap **I've paid** and send the 12-digit UPI reference (UTR).
- **Chat on the website (no Meta needed):** every page has **Chat to book** — the same assistant as on WhatsApp, running on the site itself. Guests book, get the pay link and send the UTR in the chat; the owner's confirmation comes back into the same chat. A chat is tied to the visitor's browser, so nobody can see or cancel someone else's booking by typing their number.
- **Owner app:** the console installs on the owner's phone (*Install the app* / Add to Home Screen) and opens on **Today** — rooms free tonight, new bookings, money received, payments waiting, arrivals and departures. With alerts on, every payment arrives as a notification with **Acknowledge** / **Not received** that work straight from the notification, then offers a one-tap WhatsApp confirmation to the guest from the owner's own WhatsApp. A 9 PM summary arrives every day.
- **Booking on the website:** **Book now** on any room → sign in with a code sent to their WhatsApp (no password; the account is their phone number) → hold → pay page with UPI button, QR code and a UTR box. **My account** shows every stay, what's paid and what's due. Until the `signin_code` template is approved (`WA_TPL_OTP`), the site shows **Book on WhatsApp** instead, so nobody hits a sign-in that can't send a code.
- **The owner** gets *"Priya Sharma paid ₹1,500 advance for Room 102, UTR 777788889999"* on WhatsApp with **Acknowledge** / **Not received** — and the same list in the console. Acknowledge confirms the booking and tells the guest.
- **Extensions are self-service:** the evening before check-out (or any time, by typing *extend*) the guest picks a new check-out date. Room still free → the extra nights are held in the same room; taken → the guest picks one of the free rooms and moves. Either way they pay the extra nights in full and the owner acknowledges the payment.
- **The owner console** (`/admin`): payments to check, 14-night occupancy grid, bookings (with *Balance received* at check-in), customers, rooms, printable QR codes, and a CSV import for bookings you already have.
- **No double bookings, ever.** Postgres itself refuses overlapping stays for the same room: an `EXCLUDE` constraint, tested with parallel requests. Unpaid holds block the room and release automatically when they lapse.

## How it fits together

```
Guest / owner WhatsApp ──► Meta Cloud API ──► POST /api/whatsapp ──► bot (src/lib/bot/step.ts) ──► booking engine ──► Postgres
                               ▲                                            │
                               └──────────── Graph API send ◄───────────────┘
Vercel Cron 17:00 IST ──► /api/cron/last-day ──► last-day nudges
Website (/, /rooms, /rooms/[id]) ──► live availability ──► "Book on WhatsApp"
Owner console (/admin, password) ──► server actions ──► booking engine
```

| Piece | Where |
|---|---|
| Booking engine: availability, holds, stays & extension segments, customers | `src/lib/engine.ts` |
| Payment ledger: owed → claimed (UTR) → acknowledged, balance at check-in | `src/lib/payments.ts` |
| Website accounts (sign-in code on WhatsApp) and online booking | `src/lib/guest-auth.ts`, `src/lib/web-booking.ts`, `src/app/(guest)/{signin,account,book,pay}` |
| No-overlap guarantee | `prisma/migrations/*_booking_no_overlap/migration.sql` |
| WhatsApp bot: every message and branch, a pure function | `src/lib/bot/step.ts`, `copy.ts` |
| WhatsApp transport: signature check, dedupe, 24h window, templates | `src/lib/wa/*`, `src/app/api/whatsapp/route.ts` |
| Owner console | `src/app/admin/**`, `src/lib/admin-ops.ts`, `src/lib/admin-data.ts` |
| Property details (name, address, WhatsApp number, check-in times, advance %) | `src/config.ts` |

Stack: Next.js 16 (App Router) · TypeScript · Prisma 7 + PostgreSQL · WhatsApp Cloud API · Tailwind CSS v4 · Vercel.

## Run it locally

Needs Node 22+ and Docker.

```bash
npm install                 # also generates the Prisma client
npm run db:up               # Postgres 16 in Docker on localhost:55432 (+ a test database)
cp .env.example .env        # then set ADMIN_PASSWORD and SESSION_SECRET
npm run db:migrate
npm run db:seed             # the 8 rooms
npm run dev                 # http://localhost:3000 — owner console at /admin
```

To talk to the bot locally, expose the dev server with a tunnel, e.g. `cloudflared tunnel --url http://localhost:3000`, and point Meta's webhook at `https://<tunnel>/api/whatsapp` (see below).

### Tests

```bash
npm test                    # 232 tests: website chat, owner app, dates/IST, engine, payments, stays, concurrency, bot transcripts (on Postgres), webhook, website booking, sign-in, admin
npm run build && npm run e2e   # production build + mock WhatsApp: full guest/owner journeys over signed webhooks
```

`npm test` only ever touches `TEST_DATABASE_URL`, and refuses to run without it.

## Configuration

Everything secret or per-environment is an environment variable. `.env.example` lists them all.

| Variable | What it is |
|---|---|
| `DATABASE_URL` | Postgres connection. On Neon use the **pooled** URL (host contains `-pooler`), with `sslmode=verify-full`. |
| `DIRECT_DATABASE_URL` | Production only: Neon's **direct** URL (same without `-pooler`). Used by migrations during the build. |
| `ADMIN_PASSWORD` | Owner console password. |
| `SESSION_SECRET` | 32+ random characters. Changing it signs everyone out. `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `WA_ACCESS_TOKEN` | Meta permanent (system-user) token. |
| `WA_PHONE_NUMBER_ID` | Meta → WhatsApp → API Setup → Phone number ID. |
| `WA_APP_SECRET` | Meta app → Settings → Basic → App secret. Every webhook is verified with it. |
| `WA_VERIFY_TOKEN` | Any string you choose; enter the same one in Meta's webhook settings. |
| `NEXT_PUBLIC_VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` | Owner app notifications (Web Push). Generate once with `npx web-push generate-vapid-keys`. Without them the app works, just without notifications. |
| `WA_TPL_NOTIFY`, `WA_TPL_LAST_DAY`, `WA_TPL_OTP`, `WA_TPL_LANG` | Approved template names and their language code (see [Templates](#message-templates)). |
| `OWNER_WHATSAPP` | Owner / front-desk personal WhatsApp number(s), digits with country code, comma-separated. **Not** the business number. Only these numbers can acknowledge payments. |
| `UPI_ID`, `UPI_PAYEE_NAME` | Where guests pay the advance. Shown in chat with a `upi://` pay link. |
| `HOLD_MINUTES` | How long an unpaid booking holds the room (default 120). |
| `CRON_SECRET` | Protects `/api/cron/last-day` (Vercel sends it automatically). |
| `NEXT_PUBLIC_BASE_URL` | The public site URL, e.g. `https://smart-qr-booking.vercel.app`. |

The property name, address, check-in/out times, the WhatsApp number shown on the site and QR codes (`whatsappNumber`), and the advance share (`advanceRate`) are in `src/config.ts`.

## Deploy (Vercel + Neon)

1. **Database:** the Neon database is already migrated and seeded with the 8 rooms. For a fresh one: `DIRECT_DATABASE_URL=<direct url> npx prisma migrate deploy`, then `DATABASE_URL=<pooled url> npm run db:seed`.
2. **Vercel → Project → Settings → Environment Variables:** add every variable from the table above, scoped to **Production**. Keep the database variables out of Preview, or point Preview at a separate Neon branch, so preview deployments never touch live bookings.
3. **Deploy.** On production builds `vercel.json` runs `prisma migrate deploy` before `next build`, so future schema changes apply themselves. Preview builds skip it. `vercel.json` also registers the daily cron (17:00 IST).
4. Open `https://<domain>/api/health`. It should say `{"ok":true,"rooms":8}`.
5. Sign in at `https://<domain>/admin`.

## WhatsApp go-live checklist

1. **Meta app:** at developers.facebook.com create an app (type *Business*) and add the **WhatsApp** product.
2. **Phone number:** in *WhatsApp → API Setup*, add the business number (+91 86374 66746).
   > ⚠️ A number registered on the Cloud API **stops working in the WhatsApp / WhatsApp Business phone app**. Delete it from the phone app first, and use a different phone for the owner (`OWNER_WHATSAPP`). While setting up, Meta's free test number works too; add the owner's phone as a test recipient.
3. **Permanent token:** in *Business settings → Users → System users*, add an admin system user. Assign it the app and the WhatsApp account, then generate a token with `whatsapp_business_messaging` and `whatsapp_business_management`. That is `WA_ACCESS_TOKEN`.
4. **Webhook:** in *WhatsApp → Configuration*, set the Callback URL to `https://<domain>/api/whatsapp` and the Verify token to your `WA_VERIFY_TOKEN`. Verify, then **subscribe to `messages`**.
5. **Templates:** create and get approval for the two below.
6. Add a **payment method** to the WhatsApp Business account. Template messages are billed by Meta; replies inside a guest's 24h window are free.
7. **Print the QR codes** from `/admin/qr`. Each one opens WhatsApp on its room.
8. **Smoke test** from a phone that is not the owner's: scan a code, book, tap *Advance received* on the owner phone, and check the booking in `/admin/bookings`.

### Message templates

WhatsApp only lets a business message someone freely within **24 hours of that person's last message**. The owner rarely writes to the business number, and last-day nudges go out days after the guest last wrote. So outside that window the app sends an approved template instead, and **queues the full message**. It is delivered the moment that person replies or taps the template's button. Until the templates are approved, these messages simply wait in the queue until the person next writes in; nothing is lost.

Create them in *WhatsApp Manager → Message templates* (or through the Graph API), language **English** (`WA_TPL_LANG=en`). The wording avoids the property's name, so the templates survive a rename:

| Env var | Name | Body | Buttons |
|---|---|---|---|
| `WA_TPL_NOTIFY` | `booking_update` (Utility) | `Booking update:` ⏎⏎ `{{1}}` ⏎⏎ `Tap Show options to see the full message and reply.` | Quick reply: **Show options** |
| `WA_TPL_LAST_DAY` | `stay_last_day` (Utility) | `Hi {{1}}, tomorrow ({{2}}) is the last day of your stay with us. Would you like to extend your stay or check out as planned?` | Quick reply: **Extend my stay** · Quick reply: **Check out** |
| `WA_TPL_OTP` | `signin_code` (Authentication) | Meta's standard code message (`{{1}} is your verification code…`), security recommendation on, expires in 10 minutes | **Copy code** button |

Samples for review: `{{1}}` = `Payment to check: Rs 1,800 advance for Room 101, 12 Oct to 14 Oct 2026, UTR 412345678901`; last-day `{{1}}` = `Asha`, `{{2}}` = `14 Oct 2026`.

Meta only lets **verified businesses** create Authentication templates (Business settings → Security centre → Start verification). Until then leave `WA_TPL_OTP` empty: the website shows **Book on WhatsApp** instead of sign-in.

## Day to day

- **A guest has paid:** you get their name, room, amount and UTR on WhatsApp with **Acknowledge** / **Not received** (and the same under *Payments to check* on the dashboard). Find the UTR in your UPI app or bank SMS, then tap. The guest gets their confirmation and booking ID (`HTL-20261012-007`). A UTR that was already used on another booking is flagged.
- **Existing bookings:** import them once from a spreadsheet at `/admin/import` so the bot and website know the true occupancy from day one.
- **Balance at check-in:** tap **Balance received** on the booking; the customer's total paid is kept on `/admin/customers`.
- **One unpaid hold per guest.** A guest can release their own hold (**Cancel booking**, or type *cancel*); the owner is told.
- **Unpaid holds** release on their own after `HOLD_MINUTES`. A guest who already sent their UTR isn't told it expired — acknowledging still works as long as nobody else has taken the room meanwhile (also **Payment arrived late — confirm** in `/admin/bookings`). If someone has, you're told to refund.
- **Guest asks for a person** (types *desk*): the owner gets their number with a wa.me link. Reply from your own phone; the business number itself has no chat inbox.
- **Phone / walk-in bookings:** `/admin/bookings/new`. Clashes are shown, never saved.
- **Rooms:** edit prices, descriptions and photos (image URLs) at `/admin/rooms`. *Hide* takes a room out of the site and the bot without touching its bookings. Price changes never alter existing bookings.
- **Cancelling** a WhatsApp booking in the console tells the guest in the chat. If the stay was moved to a second room, that part is cancelled too.

## Known limits

- Payments are confirmed by the owner (manual UPI). There is no payment gateway, and no automatic refunds.
- The assistant understands keywords and simple dates ("12 oct", "12/10", "tomorrow", "+2 nights"), not free-form conversation. Anything it doesn't get produces a menu, and "desk" hands the chat to a person.
- There is one owner password: no per-staff accounts and no rate limit beyond a delay on wrong passwords.
- Room photos are URLs (no upload).

Design and implementation notes: `docs/superpowers/specs/` and `docs/superpowers/plans/`.
